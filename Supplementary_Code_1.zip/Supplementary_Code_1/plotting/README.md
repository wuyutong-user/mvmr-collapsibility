# Figure sources

Current Figure 4 and Figure 5 sources are in `collider_revision_20261006/`:

- `Figure4_collider_revision_20261006.pptx`: editable workflow schematic.
- `render_workflow.py`: Figure 4 exporter; needs reportlab, lxml, Pillow and
  the Windows fonts named in the script, or equivalent user-configured fonts.
- `Figure5_collider_revision_20261006.R`: current application map and panels;
  run from its directory with ggplot2, dplyr, ggrepel, patchwork, svglite and jsonlite.

Figure 5 reads its adjacent archived aggregate inputs. The nine Collider
decision cells are Unclassified; all numeric responses and conditional F
values are retained. The source and input hashes are in the release manifest.

`manuscript_plotting_v1/R/` holds the archived continuous (current Figure 2),
binary (Figure 3) and supplementary simulation plots. Defaults locate data
relative to this package. `MVMR_PROJECT_ROOT`, `MVMR_SIM_OUTPUT_ROOT`,
`MVMR_PLOT_ROOT`, `MVMR_FIG2_DATA_ROOT` and `MVMR_FIG3_OUTPUT_ROOT` may override
the relevant defaults. Figure 2 alignment helpers are bundled in `helpers/`;
`NATURE_FIGURE_PYTHON` may select a Python 3 interpreter.

The older `Figure4_application_final_v7.R` and
`freeze_Figure4_display_classification_20260916.R` are historical application
figure scripts. They use earlier decisions and external historical inputs.
They are not current Figure 4 or Figure 5 entry points. Their optional
`IJE_HISTORICAL_PROJECT_ROOT` points to an earlier project layout.

Raw Monte Carlo replicate files are not all included. Regenerate them with the
simulation code before rendering figures that require them. Full rendering of
Figures 2 and 3 and all supplementary plots was not repeated for this release.
