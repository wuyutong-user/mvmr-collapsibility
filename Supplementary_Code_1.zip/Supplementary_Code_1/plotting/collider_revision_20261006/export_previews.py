from pathlib import Path
import pypdfium2 as pdfium
from PIL import Image
import json
WORK=Path(__file__).resolve().parent;OUT=WORK/'plots' if (WORK/'plots/Figure4_collider_revision_20261006.pdf').exists() else WORK
pdf=pdfium.PdfDocument(str(OUT/'Figure4_collider_revision_20261006.pdf'))
page=pdf[0];bitmap=page.render(scale=4775/page.get_width())
im=bitmap.to_pil().convert('RGB')
im.save(OUT/'Figure4_collider_revision_20261006.tif',compression='tiff_lzw',dpi=(300,300))
im.save(OUT/'Figure4_collider_revision_20261006.png',dpi=(300,300))
for n in ['Figure4_collider_revision_20261006.png','Figure5_collider_revision_20261006.png']:
    p=OUT/n;im=Image.open(p).convert('RGB');size=im.size;im.thumbnail((1500,1500));im.save(WORK/(p.stem+'_preview.png'))
    print(n,size)
pdf.close()
