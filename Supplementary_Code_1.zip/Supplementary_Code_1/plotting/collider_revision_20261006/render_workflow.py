"""Export the edited PowerPoint workflow's native vector shapes to PDF/TIFF."""
from pathlib import Path
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from PIL import Image
from lxml import etree
import importlib.util,json,math

HERE=Path(__file__).resolve().parent
OUT=HERE/'plots' if (HERE/'plots/Figure4_collider_revision_20261006.pptx').exists() else HERE
for tag,file in [('TNR','times.ttf'),('TNRB','timesbd.ttf'),('TNRI','timesi.ttf'),('TNRBI','timesbi.ttf'),('Arial','arial.ttf'),('ArialB','arialbd.ttf'),('ArialI','ariali.ttf'),('ArialBI','arialbi.ttf')]:
    pdfmetrics.registerFont(TTFont(tag,str(Path('C:/Windows/Fonts')/file)))
pres=Presentation(OUT/'Figure4_collider_revision_20261006.pptx')
S=72/914400;W=pres.slide_width*S;H=pres.slide_height*S
c=canvas.Canvas(str(OUT/'Figure4_collider_revision_20261006.pdf'),pagesize=(W,H))
A={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
def colour(color,default):
    try:return '#'+str(color.rgb)
    except Exception:return default
def flags(shape):
    try:
        fill=colour(shape.fill.fore_color,None) if shape.fill.type is not None else None
    except Exception:fill=None
    return fill,colour(shape.line.color,'#333333'),(shape.line.width or 12700)*S
def shapes(items,tx=0,ty=0,sx=1,sy=1):
    for shape in items:
        if shape.shape_type==MSO_SHAPE_TYPE.GROUP:
            tr=shape._element.find('p:grpSpPr/a:xfrm',{'p':'http://schemas.openxmlformats.org/presentationml/2006/main',**A})
            off=tr.find('a:chOff',A);ext=tr.find('a:chExt',A)
            fx=shape.width/int(ext.get('cx'));fy=shape.height/int(ext.get('cy'))
            yield from shapes(shape.shapes,tx+sx*(shape.left-fx*int(off.get('x'))),ty+sy*(shape.top-fy*int(off.get('y'))),sx*fx,sy*fy)
        else:yield shape,tx,ty,sx,sy
record=[]
for shape,tx,ty,sx,sy in shapes(pres.slides[0].shapes):
    x,y,w,h=(tx+shape.left*sx)*S,(ty+shape.top*sy)*S,shape.width*sx*S,shape.height*sy*S
    if shape.shape_type==MSO_SHAPE_TYPE.PICTURE:raise RuntimeError('Workflow must remain editable vector artwork')
    fill,line,width=flags(shape)
    if shape.shape_type==MSO_SHAPE_TYPE.LINE:
        x1,y1=x,H-y;x2,y2=x+w,H-y-h
        if getattr(shape,'begin_x',None) is not None:
            x1,y1,x2,y2=(tx+shape.begin_x*sx)*S,H-(ty+shape.begin_y*sy)*S,(tx+shape.end_x*sx)*S,H-(ty+shape.end_y*sy)*S
        c.setStrokeColor(HexColor(line));c.setLineWidth(width);c.line(x1,y1,x2,y2)
        end=shape._element.find('.//a:tailEnd',A)
        if end is not None and end.get('type') not in [None,'none']:
            angle=math.atan2(y2-y1,x2-x1);length=5.0
            p=c.beginPath();p.moveTo(x2,y2)
            for offset in [-0.40,0.40]:p.lineTo(x2-length*math.cos(angle+offset),y2-length*math.sin(angle+offset))
            p.close();c.setFillColor(HexColor(line));c.drawPath(p,fill=1,stroke=0)
        continue
    sppr=shape._element.find('p:spPr',{'p':'http://schemas.openxmlformats.org/presentationml/2006/main'})
    geometry=sppr.find('a:prstGeom',A) if sppr is not None else None
    if shape.shape_type!=MSO_SHAPE_TYPE.TEXT_BOX and geometry is not None and geometry.get('prst') in ['rect','roundRect']:
        c.setLineWidth(width);c.setStrokeColor(HexColor(line))
        if fill:c.setFillColor(HexColor(fill))
        c.rect(x,H-y-h,w,h,stroke=1,fill=1 if fill else 0)
    if not shape.has_text_frame:continue
    tf=shape.text_frame
    # Shape transforms rescale coordinate units; font and inset units remain EMUs/points.
    mt,mb,ml,mright=[tf.margin_top*S,tf.margin_bottom*S,tf.margin_left*S,tf.margin_right*S]
    lines=[]
    for para in tf.paragraphs:
        ppr=para._p.find('a:pPr',A);default=ppr.find('a:defRPr',A) if ppr is not None else None
        defaultsize=float(default.get('sz','1800'))/100 if default is not None else 18
        entries=[]
        for item in para._p:
            local=etree.QName(item).localname
            if local=='br':
                lines.append((para,entries));entries=[];continue
            if local not in ['r','pPr','endParaRPr']:
                # Imported native Office equations can contain the full text line.
                for node in item.xpath('.//*[local-name()="t"]'):
                    value=node.text or ''
                    if not value:continue
                    shift=0.35 if node.xpath('ancestor::*[local-name()="sup"]') else -0.25 if node.xpath('ancestor::*[local-name()="sub"]') else 0
                    size=defaultsize
                    entries.append((value,'TNR',size*(0.70 if shift else 1),shift,size,'#111111'))
                continue
            if local!='r':continue
            rpr=item.find('a:rPr',A);t=item.find('a:t',A)
            value=t.text or '' if t is not None else ''
            if not value:continue
            size=(float(rpr.get('sz',str(defaultsize*100)))/100 if rpr is not None else defaultsize)
            bold=(rpr.get('b')=='1') if rpr is not None else False
            italic=(rpr.get('i')=='1') if rpr is not None else False
            face=rpr.find('a:latin',A) if rpr is not None else None
            family='Arial' if face is not None and 'Arial' in face.get('typeface','') else 'TNR'
            font=family+('BI' if bold and italic else 'B' if bold else 'I' if italic else '')
            baseline=int(rpr.get('baseline','0'))/100000 if rpr is not None else 0
            rendered_size=size*(0.70 if baseline else 1)
            rgb=rpr.find('a:solidFill/a:srgbClr',A) if rpr is not None else None
            col='#'+rgb.get('val') if rgb is not None else '#111111'
            entries.append((value,font,rendered_size,baseline,size,col))
        lines.append((para,entries))
    if not any(entries for para,entries in lines):
        entries=[]
        for node in shape._element.xpath('.//*[local-name()="t"]'):
            value=node.text or ''
            if not value:continue
            shift=0.35 if node.xpath('ancestor::*[local-name()="sup"]') else -0.25 if node.xpath('ancestor::*[local-name()="sub"]') else 0
            size=18
            entries.append((value,'TNR',size*(0.70 if shift else 1),shift,size,'#111111'))
        if entries:lines=[(tf.paragraphs[0],entries)]
    heights=[max([r[4] for r in entries]+[14])*1.05 for para,entries in lines]
    total=sum(heights)
    anchor=tf._txBody.find('a:bodyPr',A).get('anchor','t')
    available=h-mt-mb
    top=H-y-mt-(max(0,available-total)/2 if anchor=='ctr' else max(0,available-total) if anchor=='b' else 0)
    for (para,entries),height in zip(lines,heights):
        ppr=para._p.find('a:pPr',A);align=ppr.get('algn','l') if ppr is not None else 'l'
        linewidth=sum(pdfmetrics.stringWidth(val,font,size) for val,font,size,*rest in entries)
        scale=min(1,(w-ml-mright)/linewidth) if linewidth else 1
        baseline=top-height*0.78
        xx=x+ml+(max(0,w-ml-mright-linewidth*scale)/2 if align=='ctr' else max(0,w-ml-mright-linewidth*scale) if align=='r' else 0)
        for val,font,size,shift,original,col in entries:
            c.setFont(font,size*scale);c.setFillColor(HexColor(col));c.drawString(xx,baseline+shift*original,val)
            xx+=pdfmetrics.stringWidth(val,font,size*scale)
        top-=height
    record.append(shape.text)
c.showPage();c.save()
assert any('n = 22' in t for t in record) and any('n = 12' in t for t in record)
(OUT/'Figure4_vector_export.json').write_text(json.dumps({'source':'Figure4_collider_revision_20261006.pptx','source_dimensions_points':[W,H],'editable_vector_shapes':len(pres.slides[0].shapes),'text_shapes':len(record),'export':'ReportLab native vector shapes; Times New Roman and Arial fonts embedded'},indent=2),encoding='utf-8')
print('Workflow PDF exported from edited PowerPoint geometry; raster export follows.')
