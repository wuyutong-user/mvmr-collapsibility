# Supplementary Figures S1-S2: simulation design and genetic geometry
# Run with the working directory set to manuscript_plotting_v1.

try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.936"), silent = TRUE)
summary_file <- file.path("..", "simulation_output", "summary", "primary_scenario_summary.csv")
figure_root <- "figures"
pdf_root <- file.path(figure_root, "pdf")
png_root <- file.path(figure_root, "png")
svg_root <- file.path(figure_root, "svg")
dir.create(pdf_root, recursive = TRUE, showWarnings = FALSE)
dir.create(png_root, recursive = TRUE, showWarnings = FALSE)
dir.create(svg_root, recursive = TRUE, showWarnings = FALSE)

stopifnot(file.exists(summary_file))
primary <- read.csv(summary_file, stringsAsFactors = FALSE, check.names = FALSE)
primary <- primary[primary$outcome_type == "continuous" & abs(primary$beta_x_target - 0.10) < 1e-8, ]
stopifnot(nrow(primary) == 24L)

role_order <- c(
  "confounder", "collider", "independent_cause", "upstream_surrogate_exposure",
  "downstream_surrogate_outcome", "downstream_surrogate_exposure"
)
role_labels <- c(
  "Confounder", "Collider", "Independent cause", "Upstream surrogate of exposure",
  "Downstream surrogate of outcome", "Downstream surrogate of exposure"
)
role_colours <- c("#0072B2", "#E69F00", "#009E73", "#CC79A7", "#D55E00", "#56B4E9")
config_order <- c("all_direct_classes", "no_direct_x", "no_direct_z", "no_direct_shared")
config_labels <- c("All direct classes", "No direct-X", "No direct-Z", "No direct-shared")
config_colours <- c("#0072B2", "#E69F00", "#009E73", "#CC79A7")
config_shapes <- c(16, 15, 17, 18)

save_triplet <- function(stem, draw, width = 7.2, height = 5.5) {
  pdf(file.path(pdf_root, paste0(stem, ".pdf")), width = width, height = height,
      family = "Helvetica", useDingbats = FALSE, onefile = FALSE)
  draw()
  dev.off()
  png(file.path(png_root, paste0(stem, ".png")), width = width, height = height,
      units = "in", res = 600, type = "cairo-png", bg = "white")
  draw()
  dev.off()
  svg(file.path(svg_root, paste0(stem, ".svg")), width = width, height = height,
      family = "sans", onefile = TRUE, bg = "white")
  draw()
  dev.off()
}

node_xy <- rbind(X = c(0.19, 0.34), Z = c(0.50, 0.58), Y = c(0.81, 0.34), U = c(0.50, 0.86))

draw_s1 <- function() {
  roles <- list(
    "Confounder" = c("Z-X", "Z-Y", "X-Y"),
    "Collider" = c("X-Z", "Y-Z", "X-Y"),
    "Independent cause" = c("Z-Y", "X-Y"),
    "Upstream surrogate of exposure" = c("Z-X", "X-Y"),
    "Downstream surrogate of outcome" = c("X-Y", "Y-Z"),
    "Downstream surrogate of exposure" = c("X-Z", "X-Y")
  )
  par(mfrow = c(3, 2), mar = c(0.15, 0.15, 2.4, 0.15), oma = c(2.6, 0.2, 0.1, 0.2),
      family = "sans", xaxs = "i", yaxs = "i")
  for (role in names(roles)) {
    plot.new()
    plot.window(xlim = c(0, 1), ylim = c(0, 1))
    title(main = role, cex.main = 0.85, font.main = 2, line = 0.35, col.main = "#24313A")
    edges <- strsplit(roles[[role]], "-", fixed = TRUE)[[1]]
    edge_pairs <- lapply(roles[[role]], function(edge) strsplit(edge, "-", fixed = TRUE)[[1]])
    draw_edge <- function(from, to, colour, lty = 1, lwd = 1.15, radius = 0.072) {
      a <- node_xy[from, ]; b <- node_xy[to, ]
      d <- b - a; norm <- sqrt(sum(d^2)); d <- d / norm
      arrows(a[1] + radius * d[1], a[2] + radius * d[2],
             b[1] - radius * d[1], b[2] - radius * d[2],
             length = 0.065, angle = 22, code = 2, lwd = lwd, lty = lty,
             col = colour, xpd = NA)
    }
    draw_edge("U", "X", "#7A8790", 2, 0.9, 0.105)
    draw_edge("U", "Z", "#7A8790", 2, 0.9, 0.105)
    draw_edge("U", "Y", "#7A8790", 2, 0.9, 0.105)
    for (pair in edge_pairs) draw_edge(pair[1], pair[2], "#334B5C", 1, 1.25, 0.082)
    node_labels <- c(X = "Exposure\nX", Z = "Candidate\ntrait Z", Y = "Outcome\nY", U = "Common U")
    node_fills <- c(X = "#EAF2F8", Z = "#EAF6F4", Y = "#FFF4E5", U = "#F1F2F3")
    for (node in rownames(node_xy)) {
      xy <- node_xy[node, ]
      rect(xy[1] - 0.09, xy[2] - 0.065, xy[1] + 0.09, xy[2] + 0.065,
           col = node_fills[node], border = "#334B5C", lwd = 0.85)
      text(xy[1], xy[2], node_labels[node], cex = if (node == "U") 0.60 else 0.63,
           col = "#23313A", font = 1)
    }
  }
  mtext("Solid arrows: role-specific causal paths     Dashed arrows: shared latent contribution U (coefficient 0.30)",
        side = 1, outer = TRUE, line = 1.05, cex = 0.72, col = "#3C4850")
}

draw_s2 <- function() {
  config_data <- rbind(
    direct_X = c(30, 0, 60, 50),
    direct_Z = c(30, 60, 0, 50),
    direct_shared = c(40, 40, 40, 0)
  )
  layout(matrix(c(1, 2, 3, 3), nrow = 2, byrow = TRUE), heights = c(4.1, 1.35))
  par(mar = c(5.0, 4.0, 2.6, 0.8), family = "sans", xaxs = "i", yaxs = "i")
  barplot(config_data, names.arg = c("All\n30/30/40", "No direct-X\n0/60/40", "No direct-Z\n60/0/40", "No direct-shared\n50/50/0"),
          col = c("#0072B2", "#E69F00", "#009E73"), border = "white", ylim = c(0, 100),
          ylab = "Number of SNPs (K = 100)", main = "Direct genetic-source classes",
          cex.main = 0.85, cex.names = 0.66, cex.axis = 0.72, cex.lab = 0.78)
  legend("topright", legend = c("direct_X", "direct_Z", "direct_shared"),
         fill = c("#0072B2", "#E69F00", "#009E73"), bty = "n", cex = 0.62)

  par(mar = c(5.0, 4.0, 2.6, 0.8), family = "sans", xaxs = "i", yaxs = "i")
  role_factor <- factor(primary$role, levels = role_order)
  config_factor <- factor(primary$instrument_config, levels = config_order)
  plot(primary$mean_rho_w, primary$mean_delta_xz, type = "n",
       xlab = expression("Realised weighted correlation (" * rho[W] * ")"),
       ylab = expression("Realised projection (" * delta[XZ] * ")"),
       main = "Summary-association geometry", cex.main = 0.85,
       cex.axis = 0.72, cex.lab = 0.78)
  abline(h = 0, v = 0, lty = 2, lwd = 0.7, col = "#9AA4AA")
  for (i in seq_along(role_order)) {
    for (j in seq_along(config_order)) {
      rows <- which(role_factor == role_order[i] & config_factor == config_order[j])
      points(primary$mean_rho_w[rows], primary$mean_delta_xz[rows],
             pch = config_shapes[j], col = role_colours[i], bg = role_colours[i], cex = 1.05, lwd = 0.8)
    }
  }
  plot.new()
  par(mar = c(0, 0, 0, 0), xpd = NA)
  plot.window(c(0, 1), c(0, 1))
  text(0.25, 0.86, "Point colour: prespecified DAG role", adj = 0, cex = 0.72, font = 2)
  legend(0.02, 0.78, legend = role_labels, col = role_colours, pch = 16,
         ncol = 3, bty = "n", cex = 0.62, xjust = 0, yjust = 1)
  text(0.25, 0.35, "Point shape: direct genetic-source configuration", adj = 0, cex = 0.72, font = 2)
  legend(0.02, 0.27, legend = config_labels, pch = config_shapes, col = "#34434C",
         ncol = 4, bty = "n", cex = 0.64, xjust = 0, yjust = 1)
}

save_triplet("FigS1_simulation_architecture_six_roles", draw_s1, width = 7.2, height = 6.2)
save_triplet("FigS2_direct_genetic_config_realized_geometry", draw_s2, width = 7.2, height = 5.6)
message("Saved Supplementary Figures S1-S2 in PDF, PNG (600 dpi), and SVG.")
