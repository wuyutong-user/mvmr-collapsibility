# ============================================================
# S05_strength.R
# Fig. S13 — Conditional-strength sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$strength,
  "sensitivity_strength_scenario_summary.csv"
)

dat <- read_csv(
  FILES$strength,
  show_col_types = FALSE
) |>
  mutate(
    strength_raw = str_match(
      scenario_id,
      "__(weak|borderline|strong)__strength_sensitivity"
    )[, 2]
  )

if (any(is.na(dat$strength_raw))) {
  stop(
    "Failed to parse strength level from scenario_id."
  )
}

dat <- dat |>
  add_role_labels() |>
  add_outcome_labels() |>
  mutate(
    strength_level = factor(
      strength_raw,
      levels = c(
        "weak",
        "borderline",
        "strong"
      ),
      labels = c(
        "Weak",
        "Borderline",
        "Strong"
      )
    )
  )

strength_shapes <- c(
  "Weak" = 16,
  "Borderline" = 17,
  "Strong" = 15
)

d10 <- dat |>
  filter(
    near(beta_x_target, 0.10)
  )

p13a <- role_metric_plot(
  d10,
  "median_F_min",
  "Achieved conditional strength",
  expression("Median conditional "*F[min]),
  "strength_level",
  strength_shapes,
  facet_outcome = TRUE
)

p13b <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_role_response_error",
  "Continuous response error",
  "Mean observed - predicted response",
  "strength_level",
  strength_shapes,
  ref = 0
)

p13c <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "rmse_role_response_error",
  "Continuous response reliability",
  "RMSE of role-response error",
  "strength_level",
  strength_shapes
)

p13d <- role_metric_plot(
  d10,
  "bias_adj",
  "Adjusted target-relative error",
  "Adjusted target-relative error",
  "strength_level",
  strength_shapes,
  ref = 0,
  facet_outcome = TRUE
)

p13e <- role_metric_plot(
  d10,
  "coverage_adj",
  "Adjusted 95% coverage",
  "Coverage",
  "strength_level",
  strength_shapes,
  ref = 0.95,
  facet_outcome = TRUE
)

p13f <- role_metric_plot(
  d10,
  "power_adj",
  "Adjusted power",
  "Power",
  "strength_level",
  strength_shapes,
  facet_outcome = TRUE
)

legend13 <- make_two_row_legend_strip(
  names(strength_shapes),
  strength_shapes,
  "Conditional-strength level"
)

fig_s13 <- (
  (
    p13a | p13b
  ) / (
    p13c | p13d
  ) / (
    p13e | p13f
  ) /
    patchwork::wrap_elements(full = legend13, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.24)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s13,
  "FigS13_conditional_strength_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS13_conditional_strength_sensitivity_data.csv"
  )
)

message(
  "S05_strength.R completed: Fig. S13."
)
