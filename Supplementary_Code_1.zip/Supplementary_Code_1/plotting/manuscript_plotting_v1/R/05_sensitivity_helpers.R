# ============================================================
# 05_sensitivity_helpers.R
# Shared helpers for Supplementary sensitivity figures
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(tidyr)
  library(stringr)
  library(tibble)
  library(patchwork)
})

role_label_values <- unname(ROLE_LABELS[ROLE_LEVELS])

add_role_labels <- function(dat) {
  dat |>
    mutate(
      role_label = factor(
        role,
        levels = ROLE_LEVELS,
        labels = role_label_values
      )
    )
}

two_outcome_labels <- c(
  continuous = "Continuous",
  binary = "Binary"
)

add_outcome_labels <- function(dat) {
  dat |>
    mutate(
      outcome_label = factor(
        outcome_type,
        levels = c("continuous", "binary"),
        labels = unname(
          two_outcome_labels[c("continuous", "binary")]
        )
      )
    )
}

role_metric_plot <- function(
  dat,
  xvar,
  title,
  xlab,
  shapevar,
  shape_values,
  ref = NULL,
  facet_outcome = FALSE,
  show_legend = FALSE,
  legend_title = NULL
) {

  p <- ggplot(
    dat,
    aes(
      x = .data[[xvar]],
      y = role_label,
      shape = .data[[shapevar]]
    )
  )

  if (!is.null(ref)) {
    p <- p +
      geom_vline(
        xintercept = ref,
        linewidth = 0.22,
        linetype = "dashed",
        colour = "grey45"
      )
  }

  p <- p +
    geom_point(size = 1.55) +
    scale_shape_manual(values = shape_values) +
    scale_y_discrete(
      limits = rev(role_label_values)
    ) +
    labs(
      x = xlab,
      y = NULL,
      title = title,
      shape = legend_title
    ) +
    theme_mvmr() +
    theme(
      legend.position = if (show_legend) "bottom" else "none"
    )

  if (facet_outcome) {
    p <- p +
      facet_grid(. ~ outcome_label) +
      theme(
        strip.text = element_text(
          face = "plain",
          size = STRIP_SIZE
        )
      )
  }

  p
}

make_two_row_legend_strip <- function(
  labels,
  shapes,
  title,
  display_labels = labels,
  parse_labels = FALSE
) {

  n <- length(labels)

  if (n == 2) {
    xs <- c(0.35, 3.45)
    ys <- c(1.0, 1.0)
  } else if (n == 3) {
    xs <- c(0.35, 2.4, 4.45)
    ys <- c(1.0, 1.0, 1.0)
  } else if (n == 4) {
    xs <- c(1.45, 3.75, 1.45, 3.75)
    ys <- c(1.45, 1.45, 0.55, 0.55)
  } else {
    stop("Legend strip helper supports 2-4 labels.")
  }

  df <- tibble(
    x = xs,
    y = ys,
    label = factor(labels, levels = labels),
    display_label = display_labels
  )

  ggplot() +
    annotate(
      "text",
      x = 0.05,
      y = 2.35,
      label = title,
      hjust = 0,
      size = 2.25,
      family = FONT_FAMILY
    ) +
    geom_point(
      data = df,
      aes(
        x = x,
        y = y,
        shape = label
      ),
      size = 1.45
    ) +
    geom_text(
      data = df,
      aes(
        x = x,
        y = y,
        label = display_label
      ),
      parse = parse_labels,
      nudge_x = 0.14,
      hjust = 0,
      size = 2.15,
      family = FONT_FAMILY
    ) +
    scale_shape_manual(values = shapes) +
    coord_cartesian(
      xlim = c(0, 6.2),
      ylim = c(0.25, 2.85),
      clip = "off"
    ) +
    theme_void() +
    theme(legend.position = "none")
}
