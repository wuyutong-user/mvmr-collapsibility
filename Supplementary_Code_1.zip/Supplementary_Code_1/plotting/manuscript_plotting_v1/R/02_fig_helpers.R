# ============================================================
# 02_fig_helpers.R
# Shared helpers for MVMR Supplementary figures
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(tidyr)
  library(stringr)
  library(patchwork)
  library(scales)
})

required_packages <- c(
  "ggplot2", "dplyr", "readr", "tidyr",
  "stringr", "patchwork", "scales", "svglite"
)

check_plot_packages <- function() {
  missing <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing) > 0) {
    stop(
      "Missing required R packages:\n  ",
      paste(missing, collapse = ", "),
      "\nInstall with:\n  install.packages(c(",
      paste(sprintf('"%s"', missing), collapse = ", "),
      "))",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

assert_file <- function(path, label = basename(path)) {
  if (!file.exists(path)) {
    stop("Required file not found: ", label, "\n", path, call. = FALSE)
  }
  invisible(TRUE)
}

assert_cols <- function(dat, cols, label = deparse(substitute(dat))) {
  miss <- setdiff(cols, names(dat))
  if (length(miss) > 0) {
    stop(
      label, " is missing required columns:\n  ",
      paste(miss, collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

pick_col <- function(dat, candidates, label) {
  hit <- intersect(candidates, names(dat))
  if (length(hit) == 0) {
    stop(
      "Could not identify ", label, ". Tried: ",
      paste(candidates, collapse = ", "),
      call. = FALSE
    )
  }
  hit[[1]]
}

save_mvmr_figure <- function(
  p, stem, width_mm = FIG_WIDTH_FULL_MM, height_mm, dpi = 600
) {
  check_plot_packages()

  if (height_mm > FIG_HEIGHT_MAX_MM) {
    stop(
      "Requested figure height ", height_mm,
      " mm exceeds frozen maximum ", FIG_HEIGHT_MAX_MM, " mm.",
      call. = FALSE
    )
  }

  svg_file <- file.path(SVG_ROOT, paste0(stem, ".svg"))
  pdf_file <- file.path(PDF_ROOT, paste0(stem, ".pdf"))
  png_file <- file.path(PNG_ROOT, paste0(stem, ".png"))

  dir.create(dirname(svg_file), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(pdf_file), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(png_file), recursive = TRUE, showWarnings = FALSE)

  ggsave(
    svg_file, p, width = width_mm, height = height_mm, units = "mm",
    device = svglite::svglite, bg = "white"
  )
  ggsave(
    pdf_file, p, width = width_mm, height = height_mm, units = "mm",
    device = grDevices::cairo_pdf, bg = "white"
  )
  ggsave(
    png_file, p, width = width_mm, height = height_mm, units = "mm",
    dpi = dpi, bg = "white"
  )

  message("Saved: ", stem)
  invisible(list(svg = svg_file, pdf = pdf_file, png = png_file))
}

hline_zero <- function() {
  geom_hline(
    yintercept = 0, linewidth = 0.22,
    linetype = "dashed", colour = "grey35"
  )
}

vline_zero <- function() {
  geom_vline(
    xintercept = 0, linewidth = 0.22,
    linetype = "dashed", colour = "grey35"
  )
}

wilson_ci <- function(x, n, level = 0.95) {
  z <- qnorm(1 - (1 - level) / 2)
  p <- x / n
  den <- 1 + z^2 / n
  centre <- (p + z^2 / (2 * n)) / den
  half <- z * sqrt((p * (1 - p) / n) + z^2 / (4 * n^2)) / den

  tibble(
    estimate = p,
    lower = pmax(0, centre - half),
    upper = pmin(1, centre + half)
  )
}
