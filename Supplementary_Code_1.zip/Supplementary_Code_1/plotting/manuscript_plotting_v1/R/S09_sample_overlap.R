# ============================================================
# S09_sample_overlap.R
# Fig. S17 — Sample-overlap sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$primary,
  "primary_scenario_summary.csv"
)
assert_file(
  FILES$same_sample,
  "sensitivity_same_sample_scenario_summary.csv"
)

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

same <- read_csv(
  FILES$same_sample,
  show_col_types = FALSE
)

baseline <- primary |>
  filter(
    instrument_config == "all_direct_classes",
    sample_design == "two_sample"
  )

dat <- bind_rows(
  baseline,
  same
) |>
  filter(
    sample_design %in% c(
      "two_sample",
      "same_sample"
    )
  ) |>
  add_role_labels() |>
  add_outcome_labels() |>
  mutate(
    design_label = factor(
      sample_design,
      levels = c(
        "two_sample",
        "same_sample"
      ),
      labels = c(
        "Two-sample",
        "Same-sample"
      )
    )
  )

if (nrow(dat) != 48L) {
  stop(
    "Expected 48 sample-design comparison rows; observed ",
    nrow(dat),
    "."
  )
}

design_shapes <- c(
  "Two-sample" = 16,
  "Same-sample" = 15
)

d10 <- dat |>
  filter(
    near(beta_x_target, 0.10)
  )

p17a <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_response",
  "Continuous coefficient response",
  "Mean response",
  "design_label",
  design_shapes,
  ref = 0
)

p17b <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_role_response_error",
  "Continuous response error",
  "Mean observed - predicted response",
  "design_label",
  design_shapes,
  ref = 0
)

p17c <- role_metric_plot(
  d10 |>
    filter(outcome_type == "binary"),
  "mean_response",
  "Binary total logOR response",
  "Mean total logOR response",
  "design_label",
  design_shapes,
  ref = 0
)

p17d <- role_metric_plot(
  d10,
  "bias_adj",
  "Adjusted target-relative error",
  "Adjusted target-relative error",
  "design_label",
  design_shapes,
  ref = 0,
  facet_outcome = TRUE
)

p17e <- role_metric_plot(
  d10,
  "empirical_sd_adj",
  "Adjusted empirical precision",
  "Adjusted empirical SD",
  "design_label",
  design_shapes,
  facet_outcome = TRUE
)

p17f <- role_metric_plot(
  d10,
  "coverage_adj",
  "Adjusted 95% coverage",
  "Coverage",
  "design_label",
  design_shapes,
  ref = 0.95,
  facet_outcome = TRUE
)

legend17 <- make_two_row_legend_strip(
  names(design_shapes),
  design_shapes,
  "Sample design"
)

fig_s17 <- (
  (
    p17a | p17b
  ) / (
    p17c | p17d
  ) / (
    p17e | p17f
  ) /
    patchwork::wrap_elements(full = legend17, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.22)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s17,
  "FigS17_sample_overlap_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS17_sample_overlap_sensitivity_data.csv"
  )
)

message(
  "S09_sample_overlap.R completed: Fig. S17."
)
