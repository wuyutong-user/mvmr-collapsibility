# ============================================================
# S06_alignment.R
# Fig. S14 — Direct shared-effect alignment sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$alignment,
  "sensitivity_alignment_scenario_summary.csv"
)

dat <- read_csv(
  FILES$alignment,
  show_col_types = FALSE
) |>
  mutate(
    alignment_input = as.numeric(
      str_match(
        scenario_id,
        "__rho(-?[0-9]+\\.[0-9]+)__alignment_sensitivity"
      )[, 2]
    )
  )

if (any(is.na(dat$alignment_input))) {
  stop(
    "Failed to parse direct shared-effect alignment from scenario_id."
  )
}

dat <- dat |>
  add_role_labels() |>
  add_outcome_labels() |>
  mutate(
    alignment_label = factor(
      alignment_input,
      levels = c(
        -0.80,
        0.00,
        0.95
      ),
      labels = c(
        "Input = -0.80",
        "Input = 0.00",
        "Input = 0.95"
      )
    )
  )

alignment_shapes <- c(
  "Input = -0.80" = 16,
  "Input = 0.00" = 17,
  "Input = 0.95" = 15
)

d10 <- dat |>
  filter(
    near(beta_x_target, 0.10)
  )

p14a <- role_metric_plot(
  d10,
  "mean_rho_w",
  "Realised weighted correlation",
  expression(rho[W]),
  "alignment_label",
  alignment_shapes,
  facet_outcome = TRUE
)

p14b <- role_metric_plot(
  d10,
  "mean_delta_xz",
  "Realised weighted projection",
  expression(delta[XZ]),
  "alignment_label",
  alignment_shapes,
  ref = 0,
  facet_outcome = TRUE
)

p14c <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_response",
  "Observed continuous response",
  "Observed mean response",
  "alignment_label",
  alignment_shapes,
  ref = 0
)

p14d <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_role_predicted_response",
  "Role-predicted continuous response",
  "Predicted response",
  "alignment_label",
  alignment_shapes,
  ref = 0
)

p14e <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_role_response_error",
  "Continuous calibration error",
  "Mean observed - predicted response",
  "alignment_label",
  alignment_shapes,
  ref = 0
)

p14f <- role_metric_plot(
  d10 |>
    filter(outcome_type == "binary"),
  "mean_response",
  "Binary total logOR response",
  "Mean total logOR response",
  "alignment_label",
  alignment_shapes,
  ref = 0
)

legend14 <- make_two_row_legend_strip(
  names(alignment_shapes),
  alignment_shapes,
  "Direct shared-effect alignment"
)

fig_s14 <- (
  (
    p14a | p14b
  ) / (
    p14c | p14d
  ) / (
    p14e | p14f
  ) /
    patchwork::wrap_elements(full = legend14, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.24)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s14,
  "FigS14_alignment_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS14_alignment_sensitivity_data.csv"
  )
)

message(
  "S06_alignment.R completed: Fig. S14."
)
