# ============================================================
# 00_paths.R
# MVMR manuscript plotting project
# Read-only access to frozen simulation v1.1 outputs
# ============================================================

PUBLIC_SCRIPT_DIR <- local({
  frames <- sys.frames()
  files <- Filter(Negate(is.null), lapply(frames, function(x) x$ofile))
  arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  script <- if (length(files)) tail(files, 1)[[1]] else if (length(arg)) {
    sub("^--file=", "", arg[[1]])
  } else stop("Source this script by filename or run it with Rscript.")
  dirname(normalizePath(script, winslash = "/", mustWork = TRUE))
})
source(file.path(PUBLIC_SCRIPT_DIR, "..", "..", "helpers", "public_paths.R"))
PUBLIC_PACKAGE_ROOT <- normalizePath(file.path(PUBLIC_SCRIPT_DIR, "..", "..", ".."),
                                     winslash = "/", mustWork = TRUE)
PUBLIC_PLOT_ROOT <- dirname(PUBLIC_SCRIPT_DIR)
SIM_OUTPUT_ROOT <- normalizePath(ije_simulation_output(PUBLIC_PACKAGE_ROOT),
                                winslash = "/", mustWork = TRUE)
PROJECT_ROOT <- dirname(SIM_OUTPUT_ROOT)
PLOT_ROOT <- Sys.getenv("MVMR_PLOT_ROOT", unset = PUBLIC_PLOT_ROOT)

R_ROOT        <- file.path(PLOT_ROOT, "R")
MANIFEST_ROOT <- file.path(PLOT_ROOT, "manifest")
PLOTDATA_ROOT <- file.path(PLOT_ROOT, "plotting_data")
FIG_ROOT      <- file.path(PLOT_ROOT, "figures")
SVG_ROOT      <- file.path(FIG_ROOT, "svg")
PDF_ROOT      <- file.path(FIG_ROOT, "pdf")
PNG_ROOT      <- file.path(FIG_ROOT, "png")
QA_ROOT       <- file.path(PLOT_ROOT, "qa")

dirs <- c(
  PLOT_ROOT,
  R_ROOT,
  MANIFEST_ROOT,
  PLOTDATA_ROOT,
  FIG_ROOT,
  SVG_ROOT,
  PDF_ROOT,
  PNG_ROOT,
  QA_ROOT
)

invisible(lapply(
  dirs,
  dir.create,
  recursive = TRUE,
  showWarnings = FALSE
))

# ------------------------------------------------------------
# Frozen simulation outputs
# ------------------------------------------------------------

FILES <- list(
  
  # Primary
  primary = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "primary_scenario_summary.csv"
  ),
  
  # Sensitivities
  sample_size = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_sample_size_scenario_summary.csv"
  ),
  
  strength = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_strength_scenario_summary.csv"
  ),
  
  alignment = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_alignment_scenario_summary.csv"
  ),
  
  prevalence = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_binary_prevalence_scenario_summary.csv"
  ),
  
  effect_size = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_effect_size_005_scenario_summary.csv"
  ),
  
  same_sample = file.path(
    SIM_OUTPUT_ROOT,
    "summary",
    "sensitivity_same_sample_scenario_summary.csv"
  ),
  
  # Exact theorem modules
  theorem1 = file.path(
    SIM_OUTPUT_ROOT,
    "theorem",
    "theorem1_exact_calibration.csv"
  ),
  
  binary_scale = file.path(
    SIM_OUTPUT_ROOT,
    "theorem",
    "binary_scale_calibration.csv"
  ),
  
  # Validation
  strength_pilot = file.path(
    SIM_OUTPUT_ROOT,
    "validation",
    "strength_pilot_grid.csv"
  ),
  
  strength_recommendation = file.path(
    SIM_OUTPUT_ROOT,
    "validation",
    "strength_rms_recommendation.csv"
  ),
  
  preflight = file.path(
    SIM_OUTPUT_ROOT,
    "validation",
    "preflight_audit.txt"
  )
)

RAW <- list(
  
  primary = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "primary"
  ),
  
  same_sample = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "same_sample"
  ),
  
  alignment = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "alignment"
  ),
  
  sample_size = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "sample_size"
  ),
  
  prevalence = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "binary_prevalence"
  ),
  
  effect_size = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "effect_size_005"
  ),
  
  strength = file.path(
    SIM_OUTPUT_ROOT,
    "raw",
    "sensitivity",
    "strength"
  )
)

# ------------------------------------------------------------
# Safety checks
# ------------------------------------------------------------

missing_files <- names(FILES)[
  !file.exists(unlist(FILES))
]

if (length(missing_files) > 0) {
  warning(
    "These expected simulation outputs are missing:\n",
    paste(missing_files, collapse = "\n")
  )
}

message("Simulation output root: ", SIM_OUTPUT_ROOT)
message("Plotting project root:   ", PLOT_ROOT)
