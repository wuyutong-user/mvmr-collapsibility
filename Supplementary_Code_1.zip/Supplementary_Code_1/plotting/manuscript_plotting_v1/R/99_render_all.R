# ============================================================
# 99_render_all.R
# Full Supplementary simulation figure build
# ============================================================

cat("\n")
cat("============================================================\n")
cat("MVMR supplementary figure build\n")
cat("============================================================\n\n")

source("R/03_figure_manifest.R")
source("R/04_data_audit.R")

source("R/S01_design_theory.R")
source("R/S02_primary_continuous.R")
source("R/S03_primary_binary.R")

source("R/S04_sample_size.R")
source("R/S05_strength.R")
source("R/S06_alignment.R")
source("R/S07_prevalence.R")
source("R/S08_effect_size.R")
source("R/S09_sample_overlap.R")

cat("\n")
cat("============================================================\n")
cat("FULL SUPPLEMENTARY SIMULATION BUILD COMPLETE\n")
cat("Rendered: Fig. S3-S18 except S1-S2 design panels\n")
cat("S1-S2 remain reserved for final design/DAG artwork.\n")
cat("============================================================\n")
