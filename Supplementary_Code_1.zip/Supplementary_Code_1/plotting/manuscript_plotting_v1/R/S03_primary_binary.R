# ============================================================
# S03_primary_binary.R
# Primary binary-outcome Supplementary figures
#
# Generates:
#   Fig. S9  Full binary total-logOR coefficient response
#   Fig. S10 Replicate-level target-relative total-logOR error
#   Fig. S11 Binary estimator operating characteristics
#
# Interpretation rules:
#   - realistic binary simulations report TOTAL logOR response;
#   - structural and scale components are not separately
#     identified from marginal summary data;
#   - never label realistic binary results "structural bias";
#   - instrument_config is the DIRECT genetic-effect class.
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

check_plot_packages()

role_label_values <- unname(ROLE_LABELS[ROLE_LEVELS])
config_label_values <- unname(CONFIG_LABELS[CONFIG_LEVELS])

config_shape_values <- setNames(
  unname(CONFIG_SHAPES[CONFIG_LEVELS]),
  config_label_values
)


make_config_legend_strip <- function() {

  legend_df <- tibble(
    x = c(1.45, 3.75, 1.45, 3.75),
    y = c(2, 2, 1, 1),
    config_label = factor(
      config_label_values,
      levels = config_label_values
    )
  )

  ggplot() +
    annotate(
      "text",
      x = 0.05,
      y = 1.5,
      label = "Direct genetic-effect configuration",
      hjust = 0,
      size = 2.25,
      family = FONT_FAMILY
    ) +
    geom_point(
      data = legend_df,
      aes(
        x = x,
        y = y,
        shape = config_label
      ),
      size = 1.45
    ) +
    geom_text(
      data = legend_df,
      aes(
        x = x,
        y = y,
        label = config_label
      ),
      nudge_x = 0.14,
      hjust = 0,
      size = 2.15,
      family = FONT_FAMILY
    ) +
    scale_shape_manual(values = config_shape_values) +
    coord_cartesian(
      xlim = c(0, 6.1),
      ylim = c(0.5, 2.5),
      clip = "off"
    ) +
    theme_void() +
    theme(
      legend.position = "none",
      plot.margin = margin(0, 1, 0, 1, unit = "mm")
    )
}


alpha_nonzero_roles <- c(
  "confounder",
  "independent_cause"
)

alpha_zero_roles <- c(
  "collider",
  "upstream_surrogate_exposure",
  "downstream_surrogate_outcome",
  "downstream_surrogate_exposure"
)

prepare_primary_binary <- function(dat, beta = 0.10) {
  dat |>
    filter(
      outcome_type == "binary",
      sample_design == "two_sample",
      near(beta_x_target, beta)
    ) |>
    mutate(
      role_label = factor(
        role,
        levels = ROLE_LEVELS,
        labels = role_label_values
      ),
      config_label = factor(
        instrument_config,
        levels = CONFIG_LEVELS,
        labels = config_label_values
      )
    )
}

# ============================================================
# Load and audit primary summary
# ============================================================

assert_file(FILES$primary, "primary_scenario_summary.csv")

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

assert_cols(
  primary,
  c(
    "scenario_id", "role", "outcome_type",
    "sample_design", "beta_x_target",
    "instrument_config", "n_requested",
    "mean_response",
    "mean_role_predicted_response",
    "bias_unadj", "bias_adj",
    "rmse_unadj", "rmse_adj",
    "type1_error_unadj", "type1_error_adj",
    "power_unadj", "power_adj",
    "coverage_unadj", "coverage_adj",
    "mean_model_se_unadj", "mean_model_se_adj",
    "empirical_sd_unadj", "empirical_sd_adj"
  ),
  "primary_scenario_summary.csv"
)

bin10 <- prepare_primary_binary(primary, beta = 0.10)
bin00 <- prepare_primary_binary(primary, beta = 0.00)

if (nrow(bin10) != 24L) {
  stop(
    "Expected 24 binary beta=0.10 primary scenarios; observed ",
    nrow(bin10), ".",
    call. = FALSE
  )
}

if (nrow(bin00) != 24L) {
  stop(
    "Expected 24 binary beta=0 primary scenarios; observed ",
    nrow(bin00), ".",
    call. = FALSE
  )
}

# Guard against accidental structural interpretation
if (!all(is.na(bin10$mean_role_predicted_response)) ||
    !all(is.na(bin00$mean_role_predicted_response))) {
  stop(
    paste(
      "Realistic binary summary contains non-NA",
      "mean_role_predicted_response.",
      "Do not proceed until the source is audited."
    ),
    call. = FALSE
  )
}

# ============================================================
# Figure S9
# Full binary total-logOR coefficient response
# ============================================================

s9_nonzero <- bin10 |>
  filter(role %in% alpha_nonzero_roles)

s9_zero <- bin10 |>
  filter(role %in% alpha_zero_roles)

p_s9a <- ggplot(
  s9_nonzero,
  aes(
    x = config_label,
    y = mean_response,
    shape = config_label
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(size = 1.9) +
  scale_shape_manual(values = config_shape_values) +
  facet_wrap(~role_label, nrow = 1) +
  labs(
    x = NULL,
    y = "Mean total logOR response",
    title = expression(alpha[Z] != 0~"roles"),
    shape = "Direct genetic-effect configuration"
  ) +
  theme_mvmr() +
  theme(
    legend.position = "bottom",
    axis.text.x = element_text(angle = 25, hjust = 1)
  )

p_s9b <- ggplot(
  s9_zero,
  aes(
    x = config_label,
    y = mean_response,
    shape = config_label
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(size = 1.8) +
  scale_shape_manual(values = config_shape_values) +
  facet_wrap(~role_label, ncol = 2) +
  labs(
    x = NULL,
    y = "Mean total logOR response",
    title = expression(alpha[Z] == 0~"roles")
  ) +
  theme_mvmr() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 25, hjust = 1)
  )

fig_s9 <- (
  p_s9a /
  p_s9b
) +
  plot_layout(heights = c(0.85, 1.25)) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s9,
  "FigS9_full_binary_total_logOR_response",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  bin10,
  file.path(PLOTDATA_ROOT, "FigS9_binary_total_logOR_response_data.csv")
)

# ============================================================
# Figure S10
# Replicate-level target-relative total-logOR error
# ============================================================

raw_files <- list.files(
  RAW$primary,
  pattern = "__binary__bx0\\.10__.*__two_sample\\.rds$",
  full.names = TRUE,
  recursive = FALSE
)

if (length(raw_files) != 24L) {
  stop(
    paste0(
      "Expected 24 final raw RDS files for binary beta=0.10 ",
      "two-sample primary scenarios; found ",
      length(raw_files),
      ".\nDirectory: ",
      RAW$primary
    ),
    call. = FALSE
  )
}

read_one_binary_raw <- function(path) {
  x <- readRDS(path)

  if (!is.data.frame(x)) {
    stop(
      "Raw binary primary RDS is not a data.frame/tibble: ",
      basename(path),
      call. = FALSE
    )
  }

  assert_cols(
    x,
    c(
      "role", "outcome_type", "sample_design",
      "beta_x_target", "instrument_config",
      "beta_unadj", "beta_adj"
    ),
    basename(path)
  )

  x
}

raw_bin10 <- bind_rows(
  lapply(raw_files, read_one_binary_raw)
)

expected_raw_rows <- 24L * 1000L

if (nrow(raw_bin10) != expected_raw_rows) {
  stop(
    "Expected ",
    expected_raw_rows,
    " raw binary beta=0.10 rows; observed ",
    nrow(raw_bin10),
    ".",
    call. = FALSE
  )
}

raw_bin10_long <- raw_bin10 |>
  filter(
    outcome_type == "binary",
    sample_design == "two_sample",
    near(beta_x_target, 0.10)
  ) |>
  transmute(
    role,
    instrument_config,
    beta_x_target,
    error_unadj = beta_unadj - beta_x_target,
    error_adj = beta_adj - beta_x_target
  ) |>
  pivot_longer(
    cols = c(error_unadj, error_adj),
    names_to = "estimator",
    values_to = "target_relative_total_logOR_error"
  ) |>
  mutate(
    estimator = factor(
      estimator,
      levels = c("error_unadj", "error_adj"),
      labels = c("Unadjusted", "Adjusted")
    ),
    role_label = factor(
      role,
      levels = ROLE_LEVELS,
      labels = role_label_values
    ),
    config_label = factor(
      instrument_config,
      levels = CONFIG_LEVELS,
      labels = config_label_values
    )
  )

raw_nonzero <- raw_bin10_long |>
  filter(role %in% alpha_nonzero_roles)

raw_zero <- raw_bin10_long |>
  filter(role %in% alpha_zero_roles)

estimator_fill <- c(
  "Unadjusted" = "white",
  "Adjusted" = "grey70"
)

p_s10a <- ggplot(
  raw_nonzero,
  aes(
    x = config_label,
    y = target_relative_total_logOR_error,
    fill = estimator
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_boxplot(
    width = 0.68,
    outlier.shape = NA,
    linewidth = 0.28,
    position = position_dodge(width = 0.75)
  ) +
  scale_fill_manual(values = estimator_fill) +
  facet_wrap(~role_label, nrow = 1) +
  labs(
    x = NULL,
    y = "Target-relative total-logOR error",
    title = expression(alpha[Z] != 0~"roles"),
    fill = NULL
  ) +
  theme_mvmr() +
  theme(
    legend.position = "bottom",
    axis.text.x = element_text(angle = 25, hjust = 1)
  )

p_s10b <- ggplot(
  raw_zero,
  aes(
    x = config_label,
    y = target_relative_total_logOR_error,
    fill = estimator
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_boxplot(
    width = 0.68,
    outlier.shape = NA,
    linewidth = 0.28,
    position = position_dodge(width = 0.75)
  ) +
  scale_fill_manual(values = estimator_fill) +
  facet_wrap(~role_label, ncol = 2) +
  labs(
    x = NULL,
    y = "Target-relative total-logOR error",
    title = expression(alpha[Z] == 0~"roles")
  ) +
  theme_mvmr() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 25, hjust = 1)
  )

fig_s10 <- (
  p_s10a /
  p_s10b
) +
  plot_layout(heights = c(0.85, 1.25)) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s10,
  "FigS10_binary_target_relative_total_logOR_distributions",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  raw_bin10_long,
  file.path(
    PLOTDATA_ROOT,
    "FigS10_binary_target_relative_total_logOR_distribution_data.csv"
  )
)

# ============================================================
# Figure S11
# Binary estimator operating characteristics
# ============================================================

make_metric_long <- function(
  dat,
  unadj_col,
  adj_col,
  metric_name
) {
  dat |>
    select(
      scenario_id,
      role,
      instrument_config,
      role_label,
      config_label,
      all_of(unadj_col),
      all_of(adj_col)
    ) |>
    pivot_longer(
      cols = all_of(c(unadj_col, adj_col)),
      names_to = "estimator_raw",
      values_to = "value"
    ) |>
    mutate(
      estimator = factor(
        if_else(
          estimator_raw == unadj_col,
          "Unadjusted",
          "Adjusted"
        ),
        levels = c("Unadjusted", "Adjusted")
      ),
      metric = metric_name
    )
}

s11_error <- make_metric_long(
  bin10,
  "bias_unadj",
  "bias_adj",
  "Target-relative total-logOR error"
)

s11_rmse <- make_metric_long(
  bin10,
  "rmse_unadj",
  "rmse_adj",
  "RMSE"
)

s11_type1 <- make_metric_long(
  bin00,
  "type1_error_unadj",
  "type1_error_adj",
  "Type I error"
)

s11_power <- make_metric_long(
  bin10,
  "power_unadj",
  "power_adj",
  "Power"
)

s11_coverage <- make_metric_long(
  bin10,
  "coverage_unadj",
  "coverage_adj",
  "95% coverage"
)

s11_secal <- bin10 |>
  transmute(
    scenario_id,
    role,
    instrument_config,
    role_label,
    config_label,
    secal_unadj =
      mean_model_se_unadj / empirical_sd_unadj,
    secal_adj =
      mean_model_se_adj / empirical_sd_adj
  ) |>
  pivot_longer(
    cols = c(secal_unadj, secal_adj),
    names_to = "estimator_raw",
    values_to = "value"
  ) |>
  mutate(
    estimator = factor(
      if_else(
        estimator_raw == "secal_unadj",
        "Unadjusted",
        "Adjusted"
      ),
      levels = c("Unadjusted", "Adjusted")
    ),
    metric = "Model SE / empirical SD"
  )

metric_plot_binary <- function(
  dat,
  panel_title,
  x_label,
  ref = NULL,
  show_legend = FALSE
) {
  p <- ggplot(
    dat,
    aes(
      x = value,
      y = role_label,
      shape = config_label
    )
  )

  if (!is.null(ref)) {
    p <- p +
      geom_vline(
        xintercept = ref,
        linewidth = 0.22,
        linetype = "dashed",
        colour = "grey45"
      )
  }

  p +
    geom_point(size = 1.4) +
    scale_shape_manual(values = config_shape_values) +
    scale_y_discrete(limits = rev(role_label_values)) +
    facet_grid(. ~ estimator) +
    labs(
      x = x_label,
      y = NULL,
      title = panel_title,
      shape = "Direct genetic-effect configuration"
    ) +
    theme_mvmr() +
    theme(
      legend.position = if (show_legend) "bottom" else "none",
      strip.text = element_text(
        face = "plain",
        size = STRIP_SIZE
      )
    )
}

p_s11a <- metric_plot_binary(
  s11_error,
  "Target-relative total-logOR error",
  "Target-relative total-logOR error",
  ref = 0
)

p_s11b <- metric_plot_binary(
  s11_rmse,
  "RMSE",
  "RMSE"
)

p_s11c <- metric_plot_binary(
  s11_type1,
  "Type I error",
  "Rejection proportion",
  ref = 0.05
)

p_s11d <- metric_plot_binary(
  s11_power,
  "Power",
  "Rejection proportion"
)

p_s11e <- metric_plot_binary(
  s11_coverage,
  "95% coverage",
  "Coverage",
  ref = 0.95
)

p_s11f <- metric_plot_binary(
  s11_secal,
  "SE calibration",
  "Model SE / empirical SD",
  ref = 1,
  show_legend = FALSE
)

config_legend_s11 <- make_config_legend_strip()

fig_s11 <- (
  (
    p_s11a | p_s11b
  ) / (
    p_s11c | p_s11d
  ) / (
    p_s11e | p_s11f
  ) /
    patchwork::wrap_elements(full = config_legend_s11, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.28)
  ) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s11,
  "FigS11_binary_operating_characteristics",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  bind_rows(
    s11_error,
    s11_rmse,
    s11_type1,
    s11_power,
    s11_coverage,
    s11_secal
  ),
  file.path(
    PLOTDATA_ROOT,
    "FigS11_binary_operating_characteristics_data.csv"
  )
)

message(
  "S03_primary_binary.R completed: Fig. S9, S10 and S11."
)
