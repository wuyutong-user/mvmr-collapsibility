# ============================================================
# S08_effect_size.R
# Fig. S16 — Exposure-effect-size sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$primary,
  "primary_scenario_summary.csv"
)
assert_file(
  FILES$effect_size,
  "sensitivity_effect_size_005_scenario_summary.csv"
)

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

sens <- read_csv(
  FILES$effect_size,
  show_col_types = FALSE
)

baseline <- primary |>
  filter(
    instrument_config == "all_direct_classes",
    sample_design == "two_sample",
    near(beta_x_target, 0.10)
  )

dat <- bind_rows(
  sens,
  baseline
) |>
  filter(
    beta_x_target %in% c(
      0.05,
      0.10
    )
  ) |>
  add_role_labels() |>
  add_outcome_labels() |>
  mutate(
    effect_label = factor(
      beta_x_target,
      levels = c(
        0.05,
        0.10
      ),
      labels = c(
        "beta_X = 0.05",
        "beta_X = 0.10"
      )
    )
  )

if (nrow(dat) != 24L) {
  stop(
    "Expected 24 effect-size-comparison rows; observed ",
    nrow(dat),
    "."
  )
}

effect_shapes <- c(
  "beta_X = 0.05" = 16,
  "beta_X = 0.10" = 15
)

cont <- dat |>
  filter(
    outcome_type == "continuous"
  )

bin <- dat |>
  filter(
    outcome_type == "binary"
  )

p16a <- role_metric_plot(
  cont,
  "mean_response",
  "Continuous coefficient response",
  "Mean response",
  "effect_label",
  effect_shapes,
  ref = 0
)

p16b <- role_metric_plot(
  cont,
  "mean_role_predicted_response",
  "Role-predicted continuous response",
  "Predicted response",
  "effect_label",
  effect_shapes,
  ref = 0
)

p16c <- role_metric_plot(
  cont,
  "mean_role_response_error",
  "Continuous calibration error",
  "Mean observed - predicted response",
  "effect_label",
  effect_shapes,
  ref = 0
)

p16d <- role_metric_plot(
  bin,
  "mean_response",
  "Binary total logOR response",
  "Mean total logOR response",
  "effect_label",
  effect_shapes,
  ref = 0
)

p16e <- role_metric_plot(
  dat,
  "bias_adj",
  "Adjusted target-relative error",
  "Adjusted target-relative error",
  "effect_label",
  effect_shapes,
  ref = 0,
  facet_outcome = TRUE
)

p16f <- role_metric_plot(
  dat,
  "power_adj",
  "Adjusted power",
  "Power",
  "effect_label",
  effect_shapes,
  facet_outcome = TRUE
)

legend16 <- make_two_row_legend_strip(
  names(effect_shapes),
  effect_shapes,
  "Exposure-effect size",
  display_labels = c("beta[X] == 0.05", "beta[X] == 0.10"),
  parse_labels = TRUE
)

fig_s16 <- (
  (
    p16a | p16b
  ) / (
    p16c | p16d
  ) / (
    p16e | p16f
  ) /
    patchwork::wrap_elements(full = legend16, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.22)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s16,
  "FigS16_effect_size_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS16_effect_size_sensitivity_data.csv"
  )
)

message(
  "S08_effect_size.R completed: Fig. S16."
)
