# ============================================================
# S02_primary_continuous.R
# Primary continuous-outcome Supplementary figures v2
#
# Generates:
#   Fig. S5  Full continuous structural-response calibration
#   Fig. S6  Replicate-level target-relative error distributions
#   Fig. S7  Conventional estimator operating characteristics
#   Fig. S8  Precision and estimation reliability
#
# Frozen interpretation rules:
#   - causal role is prespecified, not inferred from response;
#   - instrument_config refers to DIRECT genetic-effect classes;
#   - response = beta_unadj - beta_adj;
#   - role-response calibration is continuous-outcome only;
#   - reliability is kept distinct from adjustment class.
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

check_plot_packages()

# ------------------------------------------------------------
# Publication labels and direct-configuration shapes
# ------------------------------------------------------------

role_label_values <- unname(ROLE_LABELS[ROLE_LEVELS])
config_label_values <- unname(CONFIG_LABELS[CONFIG_LEVELS])

config_shape_values <- setNames(
  unname(CONFIG_SHAPES[CONFIG_LEVELS]),
  config_label_values
)


make_config_legend_strip <- function() {

  legend_df <- tibble(
    x = c(1.45, 3.75, 1.45, 3.75),
    y = c(2, 2, 1, 1),
    config_label = factor(
      config_label_values,
      levels = config_label_values
    )
  )

  ggplot() +
    annotate(
      "text",
      x = 0.05,
      y = 1.5,
      label = "Direct genetic-effect configuration",
      hjust = 0,
      size = 2.25,
      family = FONT_FAMILY
    ) +
    geom_point(
      data = legend_df,
      aes(
        x = x,
        y = y,
        shape = config_label
      ),
      size = 1.45
    ) +
    geom_text(
      data = legend_df,
      aes(
        x = x,
        y = y,
        label = config_label
      ),
      nudge_x = 0.14,
      hjust = 0,
      size = 2.15,
      family = FONT_FAMILY
    ) +
    scale_shape_manual(values = config_shape_values) +
    coord_cartesian(
      xlim = c(0, 6.1),
      ylim = c(0.5, 2.5),
      clip = "off"
    ) +
    theme_void() +
    theme(
      legend.position = "none",
      plot.margin = margin(0, 1, 0, 1, unit = "mm")
    )
}


role_nonzero <- c(
  "confounder",
  "independent_cause"
)

role_zero <- c(
  "collider",
  "upstream_surrogate_exposure",
  "downstream_surrogate_outcome",
  "downstream_surrogate_exposure"
)

prepare_primary_continuous <- function(dat, beta = 0.10) {

  dat |>
    filter(
      outcome_type == "continuous",
      sample_design == "two_sample",
      near(beta_x_target, beta)
    ) |>
    mutate(
      role_label = factor(
        role,
        levels = ROLE_LEVELS,
        labels = role_label_values
      ),
      config_label = factor(
        instrument_config,
        levels = CONFIG_LEVELS,
        labels = config_label_values
      ),
      structural_group = if_else(
        role %in% role_nonzero,
        "Non-zero role-predicted response",
        "Structural-zero role-predicted response"
      )
    )
}

# ============================================================
# Load and audit primary summary
# ============================================================

assert_file(FILES$primary, "primary_scenario_summary.csv")

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

assert_cols(
  primary,
  c(
    "scenario_id", "role", "outcome_type",
    "sample_design", "beta_x_target",
    "instrument_config", "n_requested",
    "mean_response",
    "mean_role_predicted_response",
    "mean_role_response_error",
    "rmse_role_response_error",
    "bias_unadj", "bias_adj",
    "rmse_unadj", "rmse_adj",
    "type1_error_unadj", "type1_error_adj",
    "power_unadj", "power_adj",
    "coverage_unadj", "coverage_adj",
    "mean_model_se_unadj", "mean_model_se_adj",
    "empirical_sd_unadj", "empirical_sd_adj",
    "variance_ratio_adj_over_unadj",
    "median_F_min",
    "median_condition_number"
  ),
  "primary_scenario_summary.csv"
)

cont10 <- prepare_primary_continuous(primary, beta = 0.10)
cont00 <- prepare_primary_continuous(primary, beta = 0.00)

if (nrow(cont10) != 24L) {
  stop(
    "Expected 24 continuous beta=0.10 primary scenarios; observed ",
    nrow(cont10), ".",
    call. = FALSE
  )
}

if (nrow(cont00) != 24L) {
  stop(
    "Expected 24 continuous beta=0 primary scenarios; observed ",
    nrow(cont00), ".",
    call. = FALSE
  )
}

# ============================================================
# Figure S5
# Full continuous structural-response calibration
# ============================================================

s5_nonzero <- cont10 |>
  filter(role %in% role_nonzero)

s5_zero <- cont10 |>
  filter(role %in% role_zero)

p_s5a <- ggplot(
  s5_nonzero,
  aes(
    x = mean_role_predicted_response,
    y = mean_response,
    shape = config_label
  )
) +
  geom_abline(
    intercept = 0,
    slope = 1,
    linewidth = 0.30,
    linetype = "dashed",
    colour = "grey40"
  ) +
  geom_point(size = 1.9) +
  scale_shape_manual(values = config_shape_values) +
  facet_wrap(
    ~role_label,
    nrow = 1
  ) +
  labs(
    x = "Role-predicted response",
    y = "Observed mean response",
    title = "Roles with non-zero predicted response",
    shape = "Direct genetic-effect configuration"
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

p_s5b <- ggplot(
  s5_zero,
  aes(
    x = config_label,
    y = mean_response,
    shape = config_label
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(size = 1.8) +
  scale_shape_manual(values = config_shape_values) +
  facet_wrap(
    ~role_label,
    ncol = 2
  ) +
  labs(
    x = NULL,
    y = "Observed mean response",
    title = "Roles with zero predicted structural response"
  ) +
  theme_mvmr() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    )
  )

fig_s5 <- (
  p_s5a /
  p_s5b
) +
  plot_layout(
    heights = c(0.85, 1.25)
  ) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s5,
  "FigS5_full_continuous_response_calibration",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  cont10,
  file.path(PLOTDATA_ROOT, "FigS5_continuous_response_calibration_data.csv")
)

# ============================================================
# Figure S6
# Replicate-level continuous target-relative error distributions
# ============================================================

raw_files <- list.files(
  RAW$primary,
  pattern = "__continuous__bx0\\.10__.*__two_sample\\.rds$",
  full.names = TRUE,
  recursive = FALSE
)

if (length(raw_files) != 24L) {
  stop(
    paste0(
      "Expected 24 final raw RDS files for continuous beta=0.10 ",
      "two-sample primary scenarios; found ",
      length(raw_files),
      ".\nDirectory: ",
      RAW$primary
    ),
    call. = FALSE
  )
}

read_one_primary_raw <- function(path) {

  x <- readRDS(path)

  if (!is.data.frame(x)) {
    stop(
      "Raw primary RDS is not a data.frame/tibble: ",
      basename(path),
      call. = FALSE
    )
  }

  req <- c(
    "role", "outcome_type", "sample_design",
    "beta_x_target", "instrument_config",
    "beta_unadj", "beta_adj"
  )

  assert_cols(
    x,
    req,
    basename(path)
  )

  x
}

raw_cont10 <- bind_rows(
  lapply(
    raw_files,
    read_one_primary_raw
  )
)

expected_raw_rows <- 24L * 2000L

if (nrow(raw_cont10) != expected_raw_rows) {
  stop(
    "Expected ",
    expected_raw_rows,
    " raw continuous beta=0.10 rows; observed ",
    nrow(raw_cont10),
    ".",
    call. = FALSE
  )
}

raw_cont10_long <- raw_cont10 |>
  filter(
    outcome_type == "continuous",
    sample_design == "two_sample",
    near(beta_x_target, 0.10)
  ) |>
  transmute(
    role,
    instrument_config,
    beta_x_target,
    error_unadj = beta_unadj - beta_x_target,
    error_adj = beta_adj - beta_x_target
  ) |>
  pivot_longer(
    cols = c(
      error_unadj,
      error_adj
    ),
    names_to = "estimator",
    values_to = "target_relative_error"
  ) |>
  mutate(
    estimator = factor(
      estimator,
      levels = c(
        "error_unadj",
        "error_adj"
      ),
      labels = c(
        "Unadjusted",
        "Adjusted"
      )
    ),
    role_label = factor(
      role,
      levels = ROLE_LEVELS,
      labels = role_label_values
    ),
    config_label = factor(
      instrument_config,
      levels = CONFIG_LEVELS,
      labels = config_label_values
    )
  )

raw_nonzero <- raw_cont10_long |>
  filter(role %in% role_nonzero)

raw_zero <- raw_cont10_long |>
  filter(role %in% role_zero)

estimator_fill <- c(
  "Unadjusted" = "white",
  "Adjusted" = "grey70"
)

p_s6a <- ggplot(
  raw_nonzero,
  aes(
    x = config_label,
    y = target_relative_error,
    fill = estimator
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_boxplot(
    width = 0.68,
    outlier.shape = NA,
    linewidth = 0.28,
    position = position_dodge(width = 0.75)
  ) +
  scale_fill_manual(values = estimator_fill) +
  facet_wrap(
    ~role_label,
    nrow = 1
  ) +
  labs(
    x = NULL,
    y = "Target-relative estimation error",
    title = "Roles with non-zero predicted response",
    fill = NULL
  ) +
  theme_mvmr() +
  theme(
    legend.position = "bottom",
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    )
  )

p_s6b <- ggplot(
  raw_zero,
  aes(
    x = config_label,
    y = target_relative_error,
    fill = estimator
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_boxplot(
    width = 0.68,
    outlier.shape = NA,
    linewidth = 0.28,
    position = position_dodge(width = 0.75)
  ) +
  scale_fill_manual(values = estimator_fill) +
  facet_wrap(
    ~role_label,
    ncol = 2
  ) +
  labs(
    x = NULL,
    y = "Target-relative estimation error",
    title = "Structural-zero roles"
  ) +
  theme_mvmr() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    )
  )

fig_s6 <- (
  p_s6a /
  p_s6b
) +
  plot_layout(
    heights = c(0.85, 1.25)
  ) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s6,
  "FigS6_continuous_target_relative_distributions",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  raw_cont10_long,
  file.path(PLOTDATA_ROOT, "FigS6_continuous_target_relative_distribution_data.csv")
)

# ============================================================
# Figure S7
# Conventional continuous estimator operating characteristics
# ============================================================

make_metric_long <- function(
  dat,
  unadj_col,
  adj_col,
  metric_name
) {

  dat |>
    select(
      scenario_id,
      role,
      instrument_config,
      role_label,
      config_label,
      all_of(unadj_col),
      all_of(adj_col)
    ) |>
    pivot_longer(
      cols = all_of(
        c(
          unadj_col,
          adj_col
        )
      ),
      names_to = "estimator_raw",
      values_to = "value"
    ) |>
    mutate(
      estimator = if_else(
        estimator_raw == unadj_col,
        "Unadjusted",
        "Adjusted"
      ),
      estimator = factor(
        estimator,
        levels = c(
          "Unadjusted",
          "Adjusted"
        )
      ),
      metric = metric_name
    )
}

s7_bias <- make_metric_long(
  cont10,
  "bias_unadj",
  "bias_adj",
  "Bias"
)

s7_rmse <- make_metric_long(
  cont10,
  "rmse_unadj",
  "rmse_adj",
  "RMSE"
)

s7_type1 <- make_metric_long(
  cont00,
  "type1_error_unadj",
  "type1_error_adj",
  "Type I error"
)

s7_power <- make_metric_long(
  cont10,
  "power_unadj",
  "power_adj",
  "Power"
)

s7_coverage <- make_metric_long(
  cont10,
  "coverage_unadj",
  "coverage_adj",
  "95% coverage"
)

s7_secal <- cont10 |>
  transmute(
    scenario_id,
    role,
    instrument_config,
    role_label,
    config_label,
    secal_unadj =
      mean_model_se_unadj / empirical_sd_unadj,
    secal_adj =
      mean_model_se_adj / empirical_sd_adj
  ) |>
  pivot_longer(
    cols = c(
      secal_unadj,
      secal_adj
    ),
    names_to = "estimator_raw",
    values_to = "value"
  ) |>
  mutate(
    estimator = factor(
      if_else(
        estimator_raw == "secal_unadj",
        "Unadjusted",
        "Adjusted"
      ),
      levels = c(
        "Unadjusted",
        "Adjusted"
      )
    ),
    metric = "Model SE / empirical SD"
  )

metric_plot <- function(
  dat,
  panel_title,
  x_label,
  ref = NULL,
  show_legend = FALSE
) {

  p <- ggplot(
    dat,
    aes(
      x = value,
      y = role_label,
      shape = config_label
    )
  )

  if (!is.null(ref)) {
    p <- p +
      geom_vline(
        xintercept = ref,
        linewidth = 0.22,
        linetype = "dashed",
        colour = "grey45"
      )
  }

  p +
    geom_point(size = 1.4) +
    scale_shape_manual(values = config_shape_values) +
    scale_y_discrete(
      limits = rev(role_label_values)
    ) +
    facet_grid(. ~ estimator) +
    labs(
      x = x_label,
      y = NULL,
      title = panel_title,
      shape = "Direct genetic-effect configuration"
    ) +
    theme_mvmr() +
    theme(
      legend.position = if (show_legend) "bottom" else "none",
      strip.text = element_text(
        face = "plain",
        size = STRIP_SIZE
      )
    )
}

p_s7a <- metric_plot(
  s7_bias,
  "Bias",
  "Target-relative bias",
  ref = 0
)

p_s7b <- metric_plot(
  s7_rmse,
  "RMSE",
  "RMSE"
)

p_s7c <- metric_plot(
  s7_type1,
  "Type I error",
  "Rejection proportion",
  ref = 0.05
)

p_s7d <- metric_plot(
  s7_power,
  "Power",
  "Rejection proportion"
)

p_s7e <- metric_plot(
  s7_coverage,
  "95% coverage",
  "Coverage",
  ref = 0.95
)

p_s7f <- metric_plot(
  s7_secal,
  "SE calibration",
  "Model SE / empirical SD",
  ref = 1,
  show_legend = FALSE
)

config_legend_s7 <- make_config_legend_strip()

fig_s7 <- (
  (
    p_s7a | p_s7b
  ) / (
    p_s7c | p_s7d
  ) / (
    p_s7e | p_s7f
  ) /
    patchwork::wrap_elements(full = config_legend_s7, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.28)
  ) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s7,
  "FigS7_continuous_operating_characteristics",
  height_mm = FIG_HEIGHT[["T6"]]
)

s7_source <- bind_rows(
  s7_bias,
  s7_rmse,
  s7_type1,
  s7_power,
  s7_coverage,
  s7_secal
)

write_csv(
  s7_source,
  file.path(PLOTDATA_ROOT, "FigS7_continuous_operating_characteristics_data.csv")
)

# ============================================================
# Figure S8
# Continuous precision and estimation reliability
# ============================================================

s8 <- cont10 |>
  mutate(
    empirical_sd_ratio =
      empirical_sd_adj / empirical_sd_unadj
  )

reliability_plot <- function(
  dat,
  xvar,
  title,
  xlab,
  ref = NULL
) {

  p <- ggplot(
    dat,
    aes(
      x = .data[[xvar]],
      y = role_label,
      shape = config_label
    )
  )

  if (!is.null(ref)) {
    p <- p +
      geom_vline(
        xintercept = ref,
        linewidth = 0.22,
        linetype = "dashed",
        colour = "grey45"
      )
  }

  p +
    geom_point(size = 1.6) +
    scale_shape_manual(values = config_shape_values) +
    scale_y_discrete(
      limits = rev(role_label_values)
    ) +
    labs(
      x = xlab,
      y = NULL,
      title = title,
      shape = "Direct genetic-effect configuration"
    ) +
    theme_mvmr()
}

p_s8a <- reliability_plot(
  s8,
  "empirical_sd_ratio",
  "Precision consequence",
  "Empirical SD ratio, adjusted / unadjusted",
  ref = 1
) +
  theme(legend.position = "bottom") +
  guides(
    shape = guide_legend(
      nrow = 2,
      byrow = TRUE
    )
  )

p_s8b <- reliability_plot(
  s8,
  "median_F_min",
  "Conditional instrument strength",
  expression("Median conditional "*F[min])
) +
  theme(legend.position = "none")

p_s8c <- reliability_plot(
  s8,
  "median_condition_number",
  "Numerical conditioning",
  "Median condition number"
) +
  theme(legend.position = "none")

p_s8d <- reliability_plot(
  s8,
  "rmse_role_response_error",
  "Response reliability",
  "RMSE of role-response error"
) +
  theme(legend.position = "none")

fig_s8 <- (
  p_s8a | p_s8b
) / (
  p_s8c | p_s8d
) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s8,
  "FigS8_continuous_precision_reliability",
  height_mm = FIG_HEIGHT[["T4"]]
)

write_csv(
  s8,
  file.path(PLOTDATA_ROOT, "FigS8_continuous_precision_reliability_data.csv")
)

message(
  paste(
    "S02_primary_continuous.R completed:",
    "Fig. S5, S6, S7 and S8."
  )
)
