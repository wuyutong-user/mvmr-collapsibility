# Historical application figure source; see plotting/README.md for the current Figure 5.
# Freeze the simplified display classification used by the final Figure 4.
#
# The source role and decision fields are retained unchanged. This file adds
# a deterministic main-figure display layer so that the figure is complete
# without presenting 88 residual cells as Boundary or unresolved.

try(Sys.setlocale("LC_CTYPE", "Chinese_China.936"), silent = TRUE)

project_root <- Sys.getenv("IJE_HISTORICAL_PROJECT_ROOT", unset = ".")

source_file <- file.path(
  project_root,
  "mvmr_simulation_v1_1",
  "main_figures_v2",
  "Figure6",
  "Figure4_plotting_data_v1",
  "Figure4_application_data_168.csv"
)

audit_dir <- file.path(
  project_root,
  "04-application",
  "application_audit",
  "audit_20260915_simplified_rule"
)

plot_dir <- file.path(
  project_root,
  "mvmr_simulation_v1_1",
  "main_figures_v2",
  "Figure6",
  "Figure4_plotting_data_v2_simplified_roles"
)

if (!file.exists(source_file)) {
  stop("Source plotting data not found: ", source_file)
}
dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(plot_dir, recursive = TRUE, showWarnings = FALSE)

dat <- read.csv(
  source_file,
  stringsAsFactors = FALSE,
  check.names = FALSE,
  na.strings = c("", "NA"),
  fileEncoding = "UTF-8-BOM"
)
names(dat)[1] <- sub("^\\ufeff", "", names(dat)[1])

if (nrow(dat) != 168) {
  stop("Expected 168 triads, found ", nrow(dat), ".")
}
if (anyDuplicated(dat[c("candidate", "outcome")]) > 0) {
  stop("Duplicate candidate-outcome combinations detected.")
}

# Preserve the six-role assignments already retained in reporting_role. For
# residual rows, use the simple candidate-pattern display rule frozen in the
# accompanying markdown protocol. This is a figure display layer, not a
# replacement for raw_role, reporting_role, or the audit decision fields.
dat$display_role_key <- NA_character_
dat$display_role_reason <- NA_character_
dat$mediator_like_display_marker <- FALSE

resolved <- c(
  confounder = "confounder",
  collider = "collider",
  independent_cause = "independent_cause",
  upstream_surrogate_of_exposure = "upstream_surrogate_of_exposure",
  downstream_surrogate_of_outcome = "downstream_surrogate_of_outcome",
  downstream_surrogate_of_exposure = "downstream_surrogate_of_exposure"
)

is_resolved <- dat$reporting_role %in% unname(resolved)
dat$display_role_key[is_resolved] <- dat$reporting_role[is_resolved]
dat$display_role_reason[is_resolved] <-
  "Retained from the frozen integrated working-role assignment."

residual <- !is_resolved

# Directly preserve the role family when the raw role already names one of the
# six canonical structures but was downgraded only for evidence-status reasons.
idx <- residual & dat$raw_role == "independent_cause"
dat$display_role_key[idx] <- "independent_cause"
dat$display_role_reason[idx] <-
  "Independent-cause family retained under the simplified display rule."

idx <- residual & dat$raw_role == "upstream_surrogate_of_exposure"
dat$display_role_key[idx] <- "upstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "Upstream-surrogate family retained under the simplified display rule."

idx <- residual & dat$raw_role == "downstream_surrogate_of_exposure"
dat$display_role_key[idx] <- "downstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "Downstream-surrogate-of-exposure family retained under the simplified display rule."

# Candidate-specific fallback rules for the non-canonical residual states.
idx <- residual & dat$raw_role == "overlapping_measure"
dat$display_role_key[idx] <- "downstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "Overlapping body-size measures are displayed as exposure-related downstream surrogates."

idx <- residual & dat$raw_role == "ambiguous"
dat$display_role_key[idx] <- "upstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "Ambiguous LDL-C/TC rows follow the dominant upstream-surrogate pattern for that candidate."

idx <- residual & dat$raw_role == "insufficient_evidence" &
  dat$candidate %in% c("DBP", "TG")
dat$display_role_key[idx] <- "independent_cause"
dat$display_role_reason[idx] <-
  "DBP/TG residual rows follow the dominant independent-cause pattern for that candidate."

idx <- residual & dat$raw_role == "feedback_or_cycle" &
  dat$candidate %in% c("DBP", "TG")
dat$display_role_key[idx] <- "independent_cause"
dat$display_role_reason[idx] <-
  "DBP/TG feedback rows follow the dominant independent-cause pattern for that candidate."

idx <- residual & dat$raw_role == "feedback_or_cycle" &
  dat$candidate == "HbA1c"
dat$display_role_key[idx] <- "downstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "HbA1c feedback row follows the dominant exposure-related downstream pattern."

# Mediator-like rows are shown in the closest six-role colour family, with a
# visible M marker so that the X -> Z -> Y pathway is not silently conflated
# with a canonical downstream-surrogate DAG.
idx <- residual & dat$raw_role == "mediator_out_of_library"
dat$display_role_key[idx] <- "downstream_surrogate_of_exposure"
dat$display_role_reason[idx] <-
  "Mediator-like row displayed in the exposure-downstream colour family and marked M."
dat$mediator_like_display_marker[idx] <- TRUE

if (any(is.na(dat$display_role_key))) {
  bad <- paste(dat$triad_id[is.na(dat$display_role_key)], collapse = ", ")
  stop("Display-role mapping incomplete for: ", bad)
}

display_labels <- c(
  confounder = "Confounder",
  collider = "Collider",
  independent_cause = "Independent cause",
  upstream_surrogate_of_exposure = "Upstream surrogate of exposure",
  downstream_surrogate_of_outcome = "Downstream surrogate of outcome",
  downstream_surrogate_of_exposure = "Downstream surrogate of exposure"
)
dat$display_role <- unname(display_labels[dat$display_role_key])

# The three unresolved mediator-like rows are treated as Overadjustment in the
# main target-specific summary. Their original audit decision remains intact.
dat$display_adjustment_decision <- dat$adjustment_decision
dat$display_decision_reason <-
  "Retained from the frozen target-specific decision."
idx <- dat$display_adjustment_decision == "Unclassified" &
  dat$mediator_like_display_marker
dat$display_adjustment_decision[idx] <- "Overadjustment"
dat$display_decision_reason[idx] <-
  "Mediator-like pathway is displayed as Overadjustment for the BMI total-effect target."

dat$classification_freeze <- "Figure4_display_classification_freeze_20260916"

out_file <- file.path(
  audit_dir,
  "Figure4_display_classification_freeze_20260916.csv"
)
plot_file <- file.path(
  plot_dir,
  "Figure4_display_classification_freeze_20260916.csv"
)
write.csv(dat, out_file, row.names = FALSE, na = "", fileEncoding = "UTF-8")
write.csv(dat, plot_file, row.names = FALSE, na = "", fileEncoding = "UTF-8")

role_order <- c(
  "confounder", "collider", "independent_cause",
  "upstream_surrogate_of_exposure", "downstream_surrogate_of_outcome",
  "downstream_surrogate_of_exposure"
)
decision_order <- c("Necessary", "Unnecessary", "Overadjustment")
role_counts <- table(factor(dat$display_role_key, levels = role_order))
decision_counts <- table(factor(dat$display_adjustment_decision, levels = decision_order))

cat("Figure 4 display classification freeze\n")
cat("Rows: ", nrow(dat), "\n", sep = "")
cat("Roles: ", paste(as.integer(role_counts), collapse = ", "), "\n", sep = "")
cat("Decisions: ", paste(as.integer(decision_counts), collapse = ", "), "\n", sep = "")
cat("Mediator-like display markers: ", sum(dat$mediator_like_display_marker), "\n", sep = "")
cat("Wrote: ", out_file, "\n", sep = "")
cat("Copied for plotting: ", plot_file, "\n", sep = "")
