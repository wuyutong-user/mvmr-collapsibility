# ============================================================
# 04_data_audit_v2.R
# Frozen-data integrity audit before Supplementary rendering
# v2: prints diagnostic distributions before hard-stop.
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tibble)
  library(stringr)
})

check_plot_packages()

needed <- c(
  "primary", "sample_size", "strength", "alignment",
  "prevalence", "effect_size", "same_sample",
  "theorem1", "binary_scale"
)

invisible(lapply(needed, function(k) assert_file(FILES[[k]], k)))

primary      <- read_csv(FILES$primary, show_col_types = FALSE)
sample_size  <- read_csv(FILES$sample_size, show_col_types = FALSE)
strength     <- read_csv(FILES$strength, show_col_types = FALSE)
alignment    <- read_csv(FILES$alignment, show_col_types = FALSE)
prevalence   <- read_csv(FILES$prevalence, show_col_types = FALSE)
effect_size  <- read_csv(FILES$effect_size, show_col_types = FALSE)
same_sample  <- read_csv(FILES$same_sample, show_col_types = FALSE)
theorem1     <- read_csv(FILES$theorem1, show_col_types = FALSE)
binary_scale <- read_csv(FILES$binary_scale, show_col_types = FALSE)

# ------------------------------------------------------------
# Row-count audit
# ------------------------------------------------------------

expected_rows <- c(
  primary     = 96L,
  sample_size = 48L,
  strength    = 72L,
  alignment   = 72L,
  prevalence  = 12L,
  effect_size = 12L,
  same_sample = 24L
)

observed_rows <- c(
  primary     = nrow(primary),
  sample_size = nrow(sample_size),
  strength    = nrow(strength),
  alignment   = nrow(alignment),
  prevalence  = nrow(prevalence),
  effect_size = nrow(effect_size),
  same_sample = nrow(same_sample)
)

bad_counts <- names(expected_rows)[observed_rows != expected_rows]

if (length(bad_counts) > 0) {
  stop(
    "Frozen scenario-count audit failed:\n",
    paste(
      sprintf(
        "  %s: observed %d, expected %d",
        bad_counts,
        observed_rows[bad_counts],
        expected_rows[bad_counts]
      ),
      collapse = "\n"
    ),
    call. = FALSE
  )
}

# ------------------------------------------------------------
# Primary required fields
# ------------------------------------------------------------

assert_cols(
  primary,
  c(
    "scenario_id", "role", "outcome_type", "sample_design",
    "beta_x_target", "instrument_config",
    "n_requested", "n_converged", "failure_rate",
    "bias_unadj", "bias_adj",
    "empirical_sd_unadj", "empirical_sd_adj",
    "rmse_unadj", "rmse_adj",
    "coverage_unadj", "coverage_adj",
    "type1_error_unadj", "type1_error_adj",
    "power_unadj", "power_adj",
    "median_F_min", "mean_response",
    "mean_role_predicted_response",
    "mean_role_response_error",
    "rmse_role_response_error",
    "mean_rho_w", "mean_delta_xz",
    "median_condition_number",
    "max_abs_identity_error"
  ),
  "primary_scenario_summary.csv"
)

# ------------------------------------------------------------
# Primary replicate-count audit
# ------------------------------------------------------------

primary_rep_table <- primary |>
  count(outcome_type, n_requested, name = "n_scenarios") |>
  arrange(outcome_type, n_requested)

cat("\nPrimary replicate-count distribution:\n")
print(primary_rep_table)

bad_primary_reps <- primary |>
  filter(
    is.na(n_requested) |
    (outcome_type == "continuous" & n_requested != 2000) |
    (outcome_type == "binary" & n_requested != 1000)
  ) |>
  select(
    scenario_id, role, outcome_type, beta_x_target,
    instrument_config, sample_design,
    n_requested, n_converged, failure_rate
  )

dir.create(QA_ROOT, recursive = TRUE, showWarnings = FALSE)

write_csv(
  primary_rep_table,
  file.path(QA_ROOT, "primary_replicate_count_distribution.csv")
)

write_csv(
  bad_primary_reps,
  file.path(QA_ROOT, "primary_replicate_count_violations.csv")
)

if (nrow(bad_primary_reps) > 0) {
  cat("\nRows violating frozen primary replicate counts:\n")
  print(bad_primary_reps, n = Inf)

  stop(
    paste(
      "Primary replicate-count audit failed.",
      "Do NOT relax this check yet.",
      "The frozen v1.1 design requires continuous=2000 and binary=1000.",
      "Inspect qa/primary_replicate_count_violations.csv."
    ),
    call. = FALSE
  )
}

# ------------------------------------------------------------
# Sensitivity replicate counts
# ------------------------------------------------------------

sens_list <- list(
  sample_size = sample_size,
  strength = strength,
  alignment = alignment,
  prevalence = prevalence,
  effect_size = effect_size,
  same_sample = same_sample
)

sens_rep_table <- bind_rows(
  lapply(
    names(sens_list),
    function(nm) {
      sens_list[[nm]] |>
        count(n_requested, name = "n_scenarios") |>
        mutate(analysis = nm, .before = 1)
    }
  )
)

cat("\nSensitivity replicate-count distribution:\n")
print(sens_rep_table)

write_csv(
  sens_rep_table,
  file.path(QA_ROOT, "sensitivity_replicate_count_distribution.csv")
)

sens_bad <- sens_rep_table |>
  filter(is.na(n_requested) | n_requested != 1000)

if (nrow(sens_bad) > 0) {
  stop(
    "Sensitivity replicate-count audit failed. Inspect qa/sensitivity_replicate_count_distribution.csv.",
    call. = FALSE
  )
}

# ------------------------------------------------------------
# Binary interpretation safeguard
# ------------------------------------------------------------

binary_primary <- primary |>
  filter(outcome_type == "binary")

if (!all(is.na(binary_primary$mean_role_predicted_response))) {
  stop(
    paste(
      "Binary primary contains non-NA mean_role_predicted_response.",
      "Realistic marginal logOR simulations must not be treated",
      "as identifying the structural response component."
    ),
    call. = FALSE
  )
}

# ------------------------------------------------------------
# Role/configuration checks
# ------------------------------------------------------------

if (!setequal(unique(primary$role), ROLE_LEVELS)) {
  stop(
    "Primary role set does not match frozen ROLE_LEVELS.",
    call. = FALSE
  )
}

if (!setequal(unique(primary$instrument_config), CONFIG_LEVELS)) {
  stop(
    "Primary instrument_config set does not match frozen CONFIG_LEVELS.",
    call. = FALSE
  )
}

# ------------------------------------------------------------
# Failure / identity diagnostics
# ------------------------------------------------------------

max_failure <- max(
  c(
    primary$failure_rate,
    sample_size$failure_rate,
    strength$failure_rate,
    alignment$failure_rate,
    prevalence$failure_rate,
    effect_size$failure_rate,
    same_sample$failure_rate
  ),
  na.rm = TRUE
)

max_identity <- max(
  primary$max_abs_identity_error,
  na.rm = TRUE
)

# ------------------------------------------------------------
# Theorem file checks
# ------------------------------------------------------------

assert_cols(
  theorem1,
  c(
    "role", "instrument_config", "rho_w", "delta_xz",
    "alpha_z_true", "beta_x_target",
    "beta_unadj", "beta_adj",
    "response", "predicted_response", "identity_error"
  ),
  "theorem1_exact_calibration.csv"
)

assert_cols(
  binary_scale,
  c(
    "S", "residual_mode",
    "delta_xz", "delta_struct",
    "delta_scale_observed",
    "delta_total", "decomposition_error"
  ),
  "binary_scale_calibration.csv"
)

audit <- tibble(
  check = c(
    "primary rows",
    "sample-size rows",
    "strength rows",
    "alignment rows",
    "prevalence rows",
    "effect-size rows",
    "same-sample rows",
    "continuous primary replicates",
    "binary primary replicates",
    "sensitivity replicates",
    "binary structural prediction field",
    "maximum failure rate",
    "maximum primary identity error"
  ),
  observed = c(
    nrow(primary),
    nrow(sample_size),
    nrow(strength),
    nrow(alignment),
    nrow(prevalence),
    nrow(effect_size),
    nrow(same_sample),
    "2000",
    "1000",
    "1000",
    "all NA",
    format(max_failure, scientific = TRUE),
    format(max_identity, scientific = TRUE)
  ),
  status = "PASS"
)

write_csv(
  audit,
  file.path(QA_ROOT, "data_audit_v2.csv")
)

writeLines(
  c(
    "MVMR supplementary plotting data audit v2",
    "========================================",
    "",
    paste0("Simulation output root: ", SIM_OUTPUT_ROOT),
    paste0("Primary rows: ", nrow(primary), " / 96"),
    paste0("Maximum failure rate: ", format(max_failure, scientific = TRUE)),
    paste0(
      "Maximum primary identity error: ",
      format(max_identity, scientific = TRUE)
    ),
    "",
    "STATUS: PASS"
  ),
  file.path(QA_ROOT, "data_audit_v2.txt")
)

message("Data audit v2 PASS.")
