# ============================================================
# 01_fig_config.R
# Global figure specification
# ============================================================

library(ggplot2)
library(patchwork)
library(grid)

FONT_FAMILY <- "Arial"

# ------------------------------------------------------------
# Journal-size specification
# ------------------------------------------------------------

FIG_WIDTH_FULL_MM <- 183
FIG_WIDTH_HALF_MM <- 89
FIG_HEIGHT_MAX_MM <- 165

FIG_HEIGHT <- c(
  T2 = 80,
  T3 = 100,
  T4 = 120,
  T6 = 150,
  dense = 165
)

BASE_SIZE      <- 6.5
AXIS_TEXT_SIZE <- 6.0
LEGEND_SIZE    <- 6.0
STRIP_SIZE     <- 6.5
TAG_SIZE       <- 8.0

# ------------------------------------------------------------
# Frozen factor orders
# ------------------------------------------------------------

ROLE_LEVELS <- c(
  "confounder",
  "independent_cause",
  "collider",
  "upstream_surrogate_exposure",
  "downstream_surrogate_outcome",
  "downstream_surrogate_exposure"
)

ROLE_LABELS <- c(
  confounder = "Confounder",
  independent_cause = "Independent cause",
  collider = "Collider",
  upstream_surrogate_exposure =
    "Upstream surrogate of exposure",
  downstream_surrogate_outcome =
    "Downstream surrogate of outcome",
  downstream_surrogate_exposure =
    "Downstream surrogate of exposure"
)

CONFIG_LEVELS <- c(
  "all_direct_classes",
  "no_direct_x",
  "no_direct_z",
  "no_direct_shared"
)

CONFIG_LABELS <- c(
  all_direct_classes = "All direct classes",
  no_direct_x        = "No direct-X",
  no_direct_z        = "No direct-Z",
  no_direct_shared   = "No direct-shared"
)

CONFIG_SHAPES <- c(
  all_direct_classes = 16,
  no_direct_x        = 15,
  no_direct_z        = 17,
  no_direct_shared   = 18
)

ESTIMATOR_LEVELS <- c(
  "unadjusted",
  "adjusted"
)

ESTIMATOR_LABELS <- c(
  unadjusted = "Unadjusted",
  adjusted   = "Adjusted"
)

ESTIMATOR_SHAPES <- c(
  unadjusted = 16,
  adjusted   = 15
)

# ------------------------------------------------------------
# Core SCI theme
# ------------------------------------------------------------

theme_mvmr <- function() {
  
  theme_classic(
    base_size = BASE_SIZE,
    base_family = FONT_FAMILY
  ) +
    
    theme(
      
      panel.grid = element_blank(),
      
      axis.line = element_line(
        linewidth = 0.25
      ),
      
      axis.ticks = element_line(
        linewidth = 0.25
      ),
      
      axis.ticks.length = unit(
        1.4,
        "mm"
      ),
      
      axis.title = element_text(
        size = BASE_SIZE
      ),
      
      axis.text = element_text(
        size = AXIS_TEXT_SIZE
      ),
      
      strip.background =
        element_blank(),
      
      strip.text = element_text(
        size = STRIP_SIZE,
        face = "bold"
      ),
      
      legend.position = "bottom",
      
      legend.text = element_text(
        size = LEGEND_SIZE
      ),
      
      legend.title = element_text(
        size = LEGEND_SIZE
      ),
      
      legend.key.height =
        unit(3.0, "mm"),
      
      legend.key.width =
        unit(4.0, "mm"),
      
      panel.spacing =
        unit(2.5, "mm"),
      
      plot.margin =
        margin(
          2.5,
          2.5,
          2.5,
          2.5,
          unit = "mm"
        ),
      
      plot.tag = element_text(
        family = FONT_FAMILY,
        size = TAG_SIZE,
        face = "bold"
      )
    )
}

# ------------------------------------------------------------
# Standard reference lines
# ------------------------------------------------------------

ref_zero <- function() {
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed"
  )
}

ref_type1 <- function() {
  geom_hline(
    yintercept = 0.05,
    linewidth = 0.22,
    linetype = "dashed"
  )
}

ref_coverage <- function() {
  geom_hline(
    yintercept = 0.95,
    linewidth = 0.22,
    linetype = "dashed"
  )
}

ref_ratio_one <- function() {
  geom_hline(
    yintercept = 1,
    linewidth = 0.22,
    linetype = "dashed"
  )
}