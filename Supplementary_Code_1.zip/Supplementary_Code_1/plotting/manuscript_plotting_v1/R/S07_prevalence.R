# ============================================================
# S07_prevalence.R
# Fig. S15 — Binary prevalence sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$primary,
  "primary_scenario_summary.csv"
)
assert_file(
  FILES$prevalence,
  "sensitivity_binary_prevalence_scenario_summary.csv"
)

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

sens <- read_csv(
  FILES$prevalence,
  show_col_types = FALSE
) |>
  mutate(
    prevalence = as.numeric(
      str_match(
        scenario_id,
        "__prev([0-9]+\\.[0-9]+)__prevalence_sensitivity"
      )[, 2]
    )
  )

if (any(is.na(sens$prevalence))) {
  stop(
    "Failed to parse prevalence from scenario_id."
  )
}

baseline <- primary |>
  filter(
    outcome_type == "binary",
    sample_design == "two_sample",
    instrument_config == "all_direct_classes"
  ) |>
  mutate(
    prevalence = 0.10
  )

dat <- bind_rows(
  sens,
  baseline
) |>
  filter(
    prevalence %in% c(
      0.10,
      0.50
    )
  ) |>
  add_role_labels() |>
  mutate(
    prevalence_label = factor(
      prevalence,
      levels = c(
        0.10,
        0.50
      ),
      labels = c(
        "10% prevalence",
        "50% prevalence"
      )
    )
  )

if (nrow(dat) != 24L) {
  stop(
    "Expected 24 prevalence-comparison rows; observed ",
    nrow(dat),
    "."
  )
}

prev_shapes <- c(
  "10% prevalence" = 16,
  "50% prevalence" = 15
)

d10 <- dat |>
  filter(
    near(beta_x_target, 0.10)
  )

d00 <- dat |>
  filter(
    near(beta_x_target, 0.00)
  )

p15a <- role_metric_plot(
  d10,
  "mean_response",
  "Total logOR coefficient response",
  "Mean total logOR response",
  "prevalence_label",
  prev_shapes,
  ref = 0
)

p15b <- role_metric_plot(
  d10,
  "bias_adj",
  "Adjusted target-relative total-logOR error",
  "Adjusted target-relative total-logOR error",
  "prevalence_label",
  prev_shapes,
  ref = 0
)

p15c <- role_metric_plot(
  d10,
  "empirical_sd_adj",
  "Adjusted empirical precision",
  "Adjusted empirical SD",
  "prevalence_label",
  prev_shapes
)

p15d <- role_metric_plot(
  d10,
  "power_adj",
  "Adjusted power",
  "Power",
  "prevalence_label",
  prev_shapes
)

p15e <- role_metric_plot(
  d10,
  "coverage_adj",
  "Adjusted 95% coverage",
  "Coverage",
  "prevalence_label",
  prev_shapes,
  ref = 0.95
)

p15f <- role_metric_plot(
  d00,
  "type1_error_adj",
  "Adjusted Type I error",
  "Type I error",
  "prevalence_label",
  prev_shapes,
  ref = 0.05
)

legend15 <- make_two_row_legend_strip(
  names(prev_shapes),
  prev_shapes,
  "Outcome prevalence"
)

fig_s15 <- (
  (
    p15a | p15b
  ) / (
    p15c | p15d
  ) / (
    p15e | p15f
  ) /
    patchwork::wrap_elements(full = legend15, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.22)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s15,
  "FigS15_binary_prevalence_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS15_binary_prevalence_sensitivity_data.csv"
  )
)

message(
  "S07_prevalence.R completed: Fig. S15."
)
