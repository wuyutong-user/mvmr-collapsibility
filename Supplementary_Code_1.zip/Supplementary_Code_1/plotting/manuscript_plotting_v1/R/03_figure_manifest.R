# ============================================================
# 03_figure_manifest.R
# Frozen Supplementary simulation figure manifest
# Version 1.0
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")

suppressPackageStartupMessages({
  library(tibble)
  library(readr)
  library(dplyr)
})

supp_figure_manifest <- tribble(
  ~figure_id, ~script_module, ~title, ~source_type, ~source_key,
  ~data_scope, ~template, ~main_anchor, ~primary_claim,

  "S1", "S01_design_theory.R",
  "Simulation architecture across six causal structures",
  "design", "role_registry", "six prespecified DAG roles", "T6",
  "Fig. 1; Tables 1-2",
  "The six roles are prespecified causal structures and are not inferred from coefficient movement.",

  "S2", "S01_design_theory.R",
  "Direct genetic-effect configurations and realised summary-association geometry",
  "summary", "primary", "primary continuous beta=0.10", "T4",
  "Methods; Fig. 4",
  "Direct genetic-effect classes are distinct from realised summary-association geometry.",

  "S3", "S01_design_theory.R",
  "Exact calibration of the continuous-outcome response identity",
  "theorem", "theorem1", "exact theorem grid", "T4",
  "Theorem 1",
  "The exact weighted-regression response identity is numerically satisfied across theorem geometries.",

  "S4", "S01_design_theory.R",
  "Exact decomposition of binary total coefficient response",
  "theorem", "binary_scale", "3 scale factors x 5 residual modes", "T4",
  "Theorems 2-3; Fig. 5b",
  "Total logOR response decomposes into structural and scale-dependent components.",

  "S5", "S02_primary_continuous.R",
  "Full continuous structural-response calibration",
  "summary", "primary", "continuous; beta=0.10; two-sample", "T6",
  "Fig. 4a",
  "Observed continuous response follows the role-implied response and realised instrument geometry.",

  "S6", "S02_primary_continuous.R",
  "Continuous target-relative estimation distributions",
  "raw", "raw_primary", "continuous primary", "T6",
  "Fig. 4b",
  "Adjustment changes target-relative error distributions differently across roles.",

  "S7", "S02_primary_continuous.R",
  "Continuous estimator operating characteristics",
  "summary", "primary", "continuous; beta=0 and 0.10", "T6",
  "Simulation Results",
  "Bias, RMSE, rejection, coverage and SE calibration provide conventional finite-sample diagnostics.",

  "S8", "S02_primary_continuous.R",
  "Continuous precision and estimation reliability",
  "summary", "primary", "continuous; beta=0.10", "T4",
  "Fig. 4c",
  "Structural response, precision and estimation reliability are distinct consequences of adjustment.",

  "S9", "S03_primary_binary.R",
  "Full binary total logOR coefficient response",
  "summary", "primary", "binary; beta=0.10; two-sample", "T6",
  "Fig. 5a",
  "Realistic binary simulations report total logOR response, not a uniquely structural component.",

  "S10", "S03_primary_binary.R",
  "Binary target-relative total-logOR distributions",
  "raw", "raw_primary", "binary primary", "T6",
  "Fig. 5",
  "Binary estimator error is target-relative on the marginal logOR scale and may include scale-dependent variation.",

  "S11", "S03_primary_binary.R",
  "Binary estimator operating characteristics",
  "summary", "primary", "binary; beta=0 and 0.10", "T6",
  "Simulation Results",
  "Binary type I error, power, coverage, RMSE and SE calibration describe estimator operating behaviour.",

  "S12", "S04_sample_size.R",
  "Sample-size sensitivity",
  "summary", "sample_size", "N=5000, 10000, 50000", "T6",
  "Simulation sensitivity results",
  "Finite-sample response error decreases as information increases without changing structural response class.",

  "S13", "S05_strength.R",
  "Conditional-strength sensitivity",
  "summary", "strength", "weak, borderline, strong", "T6",
  "Fig. 4d",
  "Conditional weakness reduces reliability of observed response without redefining causal role.",

  "S14", "S06_alignment.R",
  "Direct shared-effect alignment sensitivity",
  "summary", "alignment", "direct alignment targets -0.80, 0, primary, 0.95", "T4",
  "Simulation sensitivity results",
  "Changing instrument-space geometry changes coefficient response while causal role remains fixed.",

  "S15", "S07_prevalence.R",
  "Binary prevalence sensitivity",
  "summary", "prevalence", "10% vs 50%", "T4",
  "Fig. 5c",
  "Outcome prevalence changes logOR-scale precision and power without identifying structural and scale components.",

  "S16", "S08_effect_size.R",
  "Exposure-effect-size sensitivity",
  "summary", "effect_size", "beta=0, 0.05, 0.10", "T4",
  "Supplementary Results",
  "Continuous coefficient response is governed primarily by alpha_Z and instrument geometry rather than beta_X.",

  "S17", "S09_sample_overlap.R",
  "Sample-overlap sensitivity",
  "summary", "same_sample", "two-sample vs same-sample", "T4",
  "Supplementary Results",
  "Sample overlap changes finite-sample behaviour but not the prespecified population structural class.",

  "S18", "S01_design_theory.R",
  "Strength calibration and frozen production settings",
  "validation", "strength_pilot", "pre-production pilot and frozen calibration", "T2",
  "Methods; reproducibility",
  "Instrument-strength levels were calibrated before production and frozen for the simulation suite."
)

scope_decisions <- tribble(
  ~analysis_id, ~analysis_name, ~status, ~reason,

  "P01",
  "Practical different-instrument-set analysis",
  "PENDING",
  "Raw practical_* fields exist, but the current manuscript does not yet define a complete prespecified reporting block.",

  "P02",
  "MR-Egger sensitivity",
  "NOT_IN_PRODUCTION",
  "Optional code exists but is not part of the frozen primary/sensitivity production pipeline."
)

dir.create(MANIFEST_ROOT, recursive = TRUE, showWarnings = FALSE)

write_csv(
  supp_figure_manifest,
  file.path(MANIFEST_ROOT, "supplementary_figure_manifest_v1.csv")
)

write_csv(
  scope_decisions,
  file.path(MANIFEST_ROOT, "simulation_scope_decisions_v1.csv")
)

message(
  "Supplementary figure manifest written: ",
  nrow(supp_figure_manifest),
  " planned figures."
)
