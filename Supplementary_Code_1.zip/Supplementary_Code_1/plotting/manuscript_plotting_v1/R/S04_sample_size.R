# ============================================================
# S04_sample_size.R
# Fig. S12 — Sample-size sensitivity
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")
source("R/05_sensitivity_helpers.R")

assert_file(
  FILES$primary,
  "primary_scenario_summary.csv"
)
assert_file(
  FILES$sample_size,
  "sensitivity_sample_size_scenario_summary.csv"
)

primary <- read_csv(
  FILES$primary,
  show_col_types = FALSE
)

sens <- read_csv(
  FILES$sample_size,
  show_col_types = FALSE
) |>
  mutate(
    N = as.numeric(
      str_match(
        scenario_id,
        "__N([0-9]+)__N_sensitivity"
      )[, 2]
    )
  )

if (any(is.na(sens$N))) {
  stop(
    "Failed to parse N from sample-size sensitivity scenario_id."
  )
}

baseline <- primary |>
  filter(
    instrument_config == "all_direct_classes",
    sample_design == "two_sample"
  ) |>
  mutate(
    N = 10000
  )

dat <- bind_rows(
  sens,
  baseline
) |>
  filter(
    N %in% c(5000, 10000, 50000)
  ) |>
  add_role_labels() |>
  add_outcome_labels() |>
  mutate(
    N_label = factor(
      N,
      levels = c(5000, 10000, 50000),
      labels = c(
        "N = 5,000",
        "N = 10,000",
        "N = 50,000"
      )
    )
  )

if (nrow(dat) != 72L) {
  stop(
    "Expected 72 rows after adding N=10,000 baseline; observed ",
    nrow(dat),
    "."
  )
}

N_shapes <- c(
  "N = 5,000" = 16,
  "N = 10,000" = 17,
  "N = 50,000" = 15
)

d10 <- dat |>
  filter(
    near(beta_x_target, 0.10)
  )

p12a <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_response",
  "Continuous coefficient response",
  "Mean response",
  "N_label",
  N_shapes,
  ref = 0
)

p12b <- role_metric_plot(
  d10 |>
    filter(outcome_type == "continuous"),
  "mean_role_response_error",
  "Continuous response error",
  "Mean observed - predicted response",
  "N_label",
  N_shapes,
  ref = 0
)

p12c <- role_metric_plot(
  d10 |>
    filter(outcome_type == "binary"),
  "mean_response",
  "Binary total logOR response",
  "Mean total logOR response",
  "N_label",
  N_shapes,
  ref = 0
)

p12d <- role_metric_plot(
  d10,
  "bias_adj",
  "Adjusted target-relative error",
  "Adjusted target-relative error",
  "N_label",
  N_shapes,
  ref = 0,
  facet_outcome = TRUE
)

p12e <- role_metric_plot(
  d10,
  "empirical_sd_adj",
  "Adjusted empirical precision",
  "Adjusted empirical SD",
  "N_label",
  N_shapes,
  facet_outcome = TRUE
)

p12f <- role_metric_plot(
  d10,
  "median_F_min",
  "Conditional instrument strength",
  expression("Median conditional "*F[min]),
  "N_label",
  N_shapes,
  facet_outcome = TRUE
)

legend12 <- make_two_row_legend_strip(
  names(N_shapes),
  N_shapes,
  "Sample size"
)

fig_s12 <- (
  (
    p12a | p12b
  ) / (
    p12c | p12d
  ) / (
    p12e | p12f
  ) /
    patchwork::wrap_elements(full = legend12, ignore_tag = TRUE)
) +
  plot_layout(
    heights = c(1, 1, 1, 0.24)
  ) +
  plot_annotation(
    tag_levels = "a"
  )

save_mvmr_figure(
  fig_s12,
  "FigS12_sample_size_sensitivity",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  dat,
  file.path(
    PLOTDATA_ROOT,
    "FigS12_sample_size_sensitivity_data.csv"
  )
)

message(
  "S04_sample_size.R completed: Fig. S12."
)
