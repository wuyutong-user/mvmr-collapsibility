# ============================================================
# S01_design_theory.R
# Final freeze candidate v5
#
# Generates:
#   Fig. S3  Exact continuous-response calibration
#   Fig. S4  Exact binary common-scale decomposition
#   Fig. S18 Strength calibration
#
# v5 minor revisions:
#   - Fig S3c shows maximum absolute identity error per geometry;
#   - Fig S4c reports error on x10^-16 scale (no crowded ticks);
#   - Fig S4d fixes x-axis breaks at S = 0.75, 1.00, 1.50;
#   - Fig S18 keeps the v3 layout (scientifically frozen).
# ============================================================

source("R/00_paths.R")
source("R/01_fig_config.R")
source("R/02_fig_helpers.R")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

check_plot_packages()

SUMMARY_GEOM_LEVELS <- c(
  "all_summary_classes",
  "no_x_only",
  "no_z_only",
  "no_shared"
)

SUMMARY_GEOM_LABELS <- c(
  all_summary_classes = "All summary classes",
  no_x_only           = "No X-only",
  no_z_only           = "No Z-only",
  no_shared           = "No summary-shared"
)

SUMMARY_GEOM_SHAPES <- c(
  all_summary_classes = 16,
  no_x_only           = 15,
  no_z_only           = 3,
  no_shared           = 17
)

shape_values_s3 <- setNames(
  unname(SUMMARY_GEOM_SHAPES[SUMMARY_GEOM_LEVELS]),
  unname(SUMMARY_GEOM_LABELS[SUMMARY_GEOM_LEVELS])
)

# ============================================================
# Figure S3
# Exact calibration of the continuous-outcome response identity
# ============================================================

assert_file(FILES$theorem1, "theorem1_exact_calibration.csv")

th1 <- read_csv(
  FILES$theorem1,
  show_col_types = FALSE
)

assert_cols(
  th1,
  c(
    "role", "instrument_config",
    "rho_w", "delta_xz",
    "alpha_z_true",
    "response", "predicted_response",
    "identity_error"
  ),
  "theorem1_exact_calibration.csv"
)

unknown_geom <- setdiff(
  unique(th1$instrument_config),
  SUMMARY_GEOM_LEVELS
)

if (length(unknown_geom) > 0) {
  stop(
    "Unexpected theorem instrument_config value(s): ",
    paste(unknown_geom, collapse = ", "),
    call. = FALSE
  )
}

th1 <- th1 |>
  mutate(
    summary_geometry = factor(
      instrument_config,
      levels = SUMMARY_GEOM_LEVELS,
      labels = unname(SUMMARY_GEOM_LABELS[SUMMARY_GEOM_LEVELS])
    ),
    abs_identity_error = abs(identity_error)
  )

p_s3a <- ggplot(
  th1,
  aes(
    x = predicted_response,
    y = response,
    shape = summary_geometry
  )
) +
  geom_abline(
    intercept = 0,
    slope = 1,
    linewidth = 0.30,
    linetype = "dashed",
    colour = "grey40"
  ) +
  geom_point(size = 1.65) +
  scale_shape_manual(values = shape_values_s3) +
  labs(
    x = "Predicted response",
    y = "Observed exact response",
    title = "Exact response calibration",
    shape = "Summary geometry"
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

p_s3b <- ggplot(
  th1,
  aes(
    x = delta_xz,
    y = response,
    shape = summary_geometry
  )
) +
  geom_vline(
    xintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(size = 1.65) +
  scale_shape_manual(values = shape_values_s3) +
  labs(
    x = expression(delta[XZ]),
    y = "Exact coefficient response",
    title = "Response and weighted projection"
  ) +
  theme_mvmr() +
  theme(legend.position = "none")

# Numerical audit: maximum absolute identity error per theorem geometry.
th1_error_max <- th1 |>
  group_by(summary_geometry) |>
  summarise(
    max_abs_identity_error = max(abs_identity_error, na.rm = TRUE),
    .groups = "drop"
  ) |>
  mutate(
    max_abs_identity_error_e16 = max_abs_identity_error * 1e16
  )

p_s3c <- ggplot(
  th1_error_max,
  aes(
    x = summary_geometry,
    y = max_abs_identity_error_e16
  )
) +
  geom_point(size = 1.8) +
  scale_y_continuous(
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.08))
  ) +
  labs(
    x = NULL,
    y = expression("Maximum |identity error| ("*10^{-16}*")"),
    title = "Numerical identity error"
  ) +
  theme_mvmr() +
  theme(
    axis.text.x = element_text(
      angle = 25,
      hjust = 1
    )
  )

p_s3d <- ggplot(
  th1,
  aes(
    x = rho_w,
    y = delta_xz,
    shape = summary_geometry
  )
) +
  geom_vline(
    xintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(size = 1.65) +
  scale_shape_manual(values = shape_values_s3) +
  labs(
    x = expression(rho[W]),
    y = expression(delta[XZ]),
    title = "Weighted correlation and projection"
  ) +
  theme_mvmr() +
  theme(legend.position = "none")

fig_s3 <- (
  p_s3a | p_s3b
) / (
  p_s3c | p_s3d
) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s3,
  "FigS3_exact_continuous_response_calibration",
  height_mm = FIG_HEIGHT[["T4"]]
)

# Save plotting data used in S3
write_csv(
  th1,
  file.path(PLOTDATA_ROOT, "FigS3_exact_calibration_data.csv")
)

# ============================================================
# Figure S4
# Exact binary common-scale decomposition
# ============================================================

assert_file(FILES$binary_scale, "binary_scale_calibration.csv")

bs <- read_csv(
  FILES$binary_scale,
  show_col_types = FALSE
)

assert_cols(
  bs,
  c(
    "S", "residual_mode",
    "delta_struct",
    "delta_scale_observed",
    "delta_total",
    "decomposition_error"
  ),
  "binary_scale_calibration.csv"
)

mode_levels <- c(
  "none",
  "reinforce",
  "partial_offset",
  "exact_offset",
  "scale_only"
)

mode_labels <- c(
  none           = "No scale residual",
  reinforce      = "Reinforce",
  partial_offset = "Partial offset",
  exact_offset   = "Exact offset",
  scale_only     = "Scale only"
)

unknown_modes <- setdiff(
  unique(bs$residual_mode),
  mode_levels
)

if (length(unknown_modes) > 0) {
  stop(
    "Unexpected residual_mode value(s): ",
    paste(unknown_modes, collapse = ", "),
    call. = FALSE
  )
}

s_values <- sort(unique(bs$S))

bs <- bs |>
  mutate(
    S_num = as.numeric(S),
    S_facet = factor(
      S,
      levels = s_values,
      labels = paste0("S = ", sprintf("%.2f", s_values))
    ),
    residual_mode = factor(
      residual_mode,
      levels = mode_levels,
      labels = unname(mode_labels[mode_levels])
    ),
    abs_decomposition_error = abs(decomposition_error),
    abs_decomposition_error_e16 = abs(decomposition_error) * 1e16
  )

long_all <- bs |>
  select(
    S_facet,
    residual_mode,
    delta_struct,
    delta_scale_observed,
    delta_total
  ) |>
  pivot_longer(
    cols = c(
      delta_struct,
      delta_scale_observed,
      delta_total
    ),
    names_to = "quantity",
    values_to = "value"
  ) |>
  mutate(
    quantity = factor(
      quantity,
      levels = c(
        "delta_struct",
        "delta_scale_observed",
        "delta_total"
      ),
      labels = c(
        "Structural",
        "Scale",
        "Total"
      )
    )
  )

quantity_shapes <- c(
  Structural = 16,
  Scale      = 17,
  Total      = 18
)

p_s4a <- ggplot(
  long_all,
  aes(
    x = value,
    y = residual_mode,
    shape = quantity
  )
) +
  geom_vline(
    xintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(
    position = position_dodge(width = 0.45),
    size = 1.75
  ) +
  scale_shape_manual(values = quantity_shapes) +
  facet_wrap(~S_facet, nrow = 1) +
  labs(
    x = "Response",
    y = NULL,
    title = "Structural, scale and total response",
    shape = NULL
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

boundary <- bs |>
  filter(
    as.character(residual_mode) %in% c(
      "Exact offset",
      "Scale only"
    )
  ) |>
  select(
    S_facet,
    residual_mode,
    delta_struct,
    delta_total
  ) |>
  pivot_longer(
    cols = c(
      delta_struct,
      delta_total
    ),
    names_to = "quantity",
    values_to = "value"
  ) |>
  mutate(
    quantity = factor(
      quantity,
      levels = c(
        "delta_struct",
        "delta_total"
      ),
      labels = c(
        "Structural",
        "Total"
      )
    )
  )

p_s4b <- ggplot(
  boundary,
  aes(
    x = value,
    y = residual_mode,
    shape = quantity
  )
) +
  geom_vline(
    xintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_point(
    position = position_dodge(width = 0.35),
    size = 1.85
  ) +
  scale_shape_manual(
    values = c(
      Structural = 16,
      Total = 18
    )
  ) +
  facet_wrap(~S_facet, nrow = 1) +
  labs(
    x = "Response",
    y = NULL,
    title = "Identification-boundary examples",
    shape = NULL
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

p_s4c <- ggplot(
  bs,
  aes(
    x = abs_decomposition_error_e16,
    y = residual_mode
  )
) +
  geom_point(size = 1.35) +
  facet_wrap(~S_facet, nrow = 1) +
  labs(
    x = expression("Absolute decomposition error ("*10^{-16}*")"),
    y = NULL,
    title = "Exact decomposition error"
  ) +
  theme_mvmr()

invariance_nonzero <- bs |>
  filter(
    as.character(residual_mode) != "Scale only"
  ) |>
  distinct(
    S_num,
    delta_struct
  ) |>
  mutate(structural_status = "Non-zero structural case")

invariance_zero <- bs |>
  filter(
    as.character(residual_mode) == "Scale only"
  ) |>
  distinct(
    S_num,
    delta_struct
  ) |>
  mutate(structural_status = "Structural-zero case")

invariance <- bind_rows(
  invariance_nonzero,
  invariance_zero
) |>
  mutate(
    structural_status = factor(
      structural_status,
      levels = c(
        "Non-zero structural case",
        "Structural-zero case"
      )
    )
  )

p_s4d <- ggplot(
  invariance,
  aes(
    x = S_num,
    y = delta_struct,
    shape = structural_status,
    group = structural_status
  )
) +
  geom_hline(
    yintercept = 0,
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey45"
  ) +
  geom_line(linewidth = 0.65) +
  geom_point(size = 1.8) +
  scale_x_continuous(
    breaks = c(0.75, 1.00, 1.50),
    labels = c("0.75", "1.00", "1.50")
  ) +
  scale_shape_manual(
    values = c(
      "Non-zero structural case" = 16,
      "Structural-zero case" = 1
    )
  ) +
  labs(
    x = "Positive common-scale factor, S",
    y = "Structural response",
    title = "Positive-scale invariance of structural status",
    shape = NULL
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

fig_s4 <- (
  p_s4a /
  (p_s4b | p_s4c) /
  p_s4d
) +
  plot_layout(
    heights = c(1.15, 1, 0.85)
  ) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s4,
  "FigS4_exact_binary_scale_decomposition",
  height_mm = FIG_HEIGHT[["T6"]]
)

write_csv(
  bs,
  file.path(PLOTDATA_ROOT, "FigS4_binary_scale_calibration_data.csv")
)

# ============================================================
# Figure S18
# Strength calibration and frozen production settings
# ============================================================

assert_file(
  FILES$strength_pilot,
  "strength_pilot_grid.csv"
)

assert_file(
  FILES$strength_recommendation,
  "strength_rms_recommendation.csv"
)

pilot <- read_csv(
  FILES$strength_pilot,
  show_col_types = FALSE
)

rec <- read_csv(
  FILES$strength_recommendation,
  show_col_types = FALSE
)

rms_col <- pick_col(
  pilot,
  c(
    "effect_rms",
    "candidate_effect_rms",
    "rms",
    "effect_rms_candidate"
  ),
  "pilot RMS column"
)

pilot_f_col <- pick_col(
  pilot,
  c(
    "median_F_min",
    "median_f_min",
    "achieved_median_F_min",
    "median_conditional_F"
  ),
  "pilot median-F column"
)

assert_cols(
  rec,
  c(
    "strength_level",
    "target_F",
    "recommended_effect_rms",
    "achieved_median_F_min"
  ),
  "strength_rms_recommendation.csv"
)

rec2 <- rec |>
  mutate(
    strength_level = factor(
      strength_level,
      levels = c(
        "weak",
        "borderline",
        "strong"
      ),
      labels = c(
        "Weak",
        "Borderline",
        "Strong"
      )
    )
  )

strength_shapes <- c(
  Weak = 16,
  Borderline = 17,
  Strong = 15
)

p_s18a <- ggplot(
  pilot,
  aes(
    x = .data[[rms_col]],
    y = .data[[pilot_f_col]]
  )
) +
  geom_hline(
    yintercept = c(5, 10, 25),
    linewidth = 0.22,
    linetype = "dashed",
    colour = "grey60"
  ) +
  geom_line(linewidth = 0.65) +
  geom_point(size = 1.35) +
  geom_point(
    data = rec2,
    aes(
      x = recommended_effect_rms,
      y = achieved_median_F_min,
      shape = strength_level
    ),
    inherit.aes = FALSE,
    size = 2.25
  ) +
  scale_shape_manual(values = strength_shapes) +
  labs(
    x = "Genetic-effect RMS",
    y = "Median conditional F",
    title = "Pre-production strength pilot",
    shape = "Frozen level"
  ) +
  theme_mvmr() +
  theme(legend.position = "bottom")

p_s18b <- ggplot(
  rec2,
  aes(
    x = target_F,
    y = achieved_median_F_min,
    shape = strength_level
  )
) +
  geom_abline(
    intercept = 0,
    slope = 1,
    linewidth = 0.30,
    linetype = "dashed",
    colour = "grey40"
  ) +
  geom_point(size = 2.1) +
  scale_shape_manual(values = strength_shapes) +
  coord_equal(
    xlim = c(4, 27),
    ylim = c(4, 27)
  ) +
  labs(
    x = "Target conditional F",
    y = "Achieved median conditional F",
    title = "Frozen production calibration",
    shape = "Frozen level"
  ) +
  theme_mvmr() +
  theme(legend.position = "none")

fig_s18 <- (
  p_s18a | p_s18b
) +
  plot_annotation(tag_levels = "a")

save_mvmr_figure(
  fig_s18,
  "FigS18_strength_calibration",
  height_mm = FIG_HEIGHT[["T2"]]
)

write_csv(
  pilot,
  file.path(PLOTDATA_ROOT, "FigS18_strength_pilot_grid_data.csv")
)

write_csv(
  rec,
  file.path(PLOTDATA_ROOT, "FigS18_strength_frozen_settings_data.csv")
)

message(
  "S01_design_theory.R completed: Fig. S3, S4 and S18."
)
