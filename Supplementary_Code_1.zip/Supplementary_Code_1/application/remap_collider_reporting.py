"""Apply the prespecified Collider reporting revision; no effect estimate is recomputed."""
from pathlib import Path
from collections import Counter
import csv
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'provenance/final_application_audit_before_collider_20261006.csv'
DESTINATION=ROOT/'reporting_input/final_application_audit_168.csv'
IDS={'T114_BMI_Glucose_HF', 'T117_BMI_Glucose_AAA', 'T153_BMI_Smoking_AF', 'T042_BMI_SBP_HTN', 'T071_BMI_HDL_C_CAD', 'T145_BMI_Smoking_AAA', 'T156_BMI_Alcohol_HF', 'T083_BMI_HDL_C_AF', 'T167_BMI_Alcohol_AF'}
with SOURCE.open(encoding='utf-8-sig',newline='') as f:
    reader=csv.DictReader(f);fields=list(reader.fieldnames);rows=list(reader)
assert len(rows)==168 and len({r['triad_id'] for r in rows})==168
assert {r['triad_id'] for r in rows if r['display_role']=='Collider'}==IDS
for row in rows:
    if row['triad_id'] not in IDS:continue
    assert row['adjustment_decision']=='Overadjustment'
    row['adjustment_decision']='Unclassified'
    if 'display_adjustment_decision' in row:row['display_adjustment_decision']='Unclassified'
    for key in ['decision_basis','display_decision_reason']:
        if key in row:row[key]='Collider role alone does not determine the consequence of candidate-trait inclusion; additional retained-instrument evidence was not established.'
    if 'decision_status' in row:row['decision_status']='unclassified_collider_instrument_structure'
assert Counter(r['adjustment_decision'] for r in rows)=={'Necessary':5,'Unnecessary':129,'Overadjustment':22,'Unclassified':12}
DESTINATION.parent.mkdir(exist_ok=True)
with DESTINATION.open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
print('PASS: only the nine Collider decision records were remapped; estimates, roles and diagnostics were retained.')
