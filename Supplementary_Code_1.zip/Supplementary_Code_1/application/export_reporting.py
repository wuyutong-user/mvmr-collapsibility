"""Reproduce the submitted eight-field export from the frozen aggregate register."""
from pathlib import Path
from collections import Counter
import csv

ROOT = Path(__file__).resolve().parent
source = ROOT / 'reporting_input/final_application_audit_168.csv'
destination = ROOT / 'check_output/Supplementary_Data_1.csv'
mapping = {
    'triad_id': 'triad_id', 'candidate_trait': 'candidate', 'outcome': 'outcome',
    'working_structural_class': 'display_role', 'mediator_like_flag': 'mediator_like_flag',
    'target_specific_adjustment_label': 'adjustment_decision',
    'observed_total_marginal_logOR_response': 'observed_response_same_set',
    'minimum_conditional_F': 'F_min'
}
with source.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 168 and len({r['triad_id'] for r in rows}) == 168
assert Counter(r['adjustment_decision'] for r in rows) == {'Necessary': 5, 'Unnecessary': 129, 'Overadjustment': 22, 'Unclassified': 12}
destination.parent.mkdir(exist_ok=True)
with destination.open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(mapping)); writer.writeheader()
    writer.writerows({target: row[key] for target, key in mapping.items()} for row in rows)
assert destination.read_bytes() == (ROOT / 'expected/Supplementary_Data_1.csv').read_bytes()
print('PASS: 168-row reporting export matches submitted CSV byte for byte; labels 5/129/22/12.')
